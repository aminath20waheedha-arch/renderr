# What if your heart swapped to a different animal every day? (2:05, 16:9, 1920x1080)

Built with kelano86/what-if-animation (Remotion + SVG). Every frame is drawn in code; the voice, sound effects and music
are already baked in (`studio/public/heart-swap-long/*.flac`), so GitHub only has to render and master.

## Render it with GitHub Actions (phone friendly: no unzipping needed)
1. On github.com make a new repository (private is fine).
2. Add file > Upload files > pick `heart-swap-long.zip` as it is (13 MB) > Commit.
3. Add file > Create new file. Name it `.github/workflows/render.yml` (typing the slashes makes the folders).
   Paste in the contents of `render.yml` and Commit. (The workflow unzips the project itself.)
4. Open the Actions tab > "Render the episode" > Run workflow. About 15-25 minutes.
5. When it turns green, open the run and download the artifact `what-if-heart-swap-2min` (a zip holding the mp4).

If you do have a computer: unzip, push the folder to a repo as-is (the workflow is already at `.github/workflows/render.yml`).

## Render on your own machine
    cd studio && npm install
    npx remotion render src/index.ts HeartSwapLong out/raw.mp4 --concurrency 4
    python3 ../finalize.py out/raw.mp4 what-if-heart-swap-2min.mp4     # needs ffmpeg

## What is where
- `script.txt` the narration and the four sourced facts.
- `studio/src/episodes/heart-swap-long/shots.tsx` the 30 shots; `episode.json` the cuts; `timeline.json` the built timeline.
- `studio/public/heart-swap-long/` voice (local Kokoro voice, since ElevenLabs was unreachable), the sound effects and the music bed.
- `studio/public/fonts/` the three fonts, bundled so rendering needs no internet.
- `tools/` the offline voice / sound helpers used to make the audio (not needed to render).
