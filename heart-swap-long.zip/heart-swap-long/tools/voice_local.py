"""Step 2: the voice. ElevenLabs text-to-speech with character timestamps, then the pauses tightened to the genre's pace.

python <skill>/scripts/voice.py <slug> [--force]
Reads  src/episodes/<slug>/episode.json  (script, voice, gaps)
Writes public/<slug>/voice_raw.mp3, public/<slug>/voice.wav (tightened), src/episodes/<slug>/words.json (word timings
       after tightening, used by plan.py) and out/<slug>/words_raw.json. Prints the credits it used.
The API is only called when the text or the voice settings change (cached by a hash), so re-running to retune the
gaps is free.

episode.json "voice" (all optional): {"id": "TX3LPaxmHKxFdv7VOQHJ", "model": "eleven_multilingual_v2",
  "settings": {"stability": 0.4, "similarity_boost": 0.8, "style": 0.35, "use_speaker_boost": true}}
episode.json "gaps" (seconds, all optional): {"word": 0.12, "comma": 0.2, "sentence": 0.3, "question": 0.45,
  "pairs": {"anything|One": 0.6}}  -> every pause longer than its limit is cut to the limit, from its middle.
"""
import base64, hashlib, json, re, sys, time

import numpy as np

import sys as _s; _s.path.insert(0,'/home/claude/what-if-animation/scripts')
from wi import SR, api, spent_since, decode, ep_dir, load_episode, load_json, log_cost, out_dir, pub_dir, save_json, write_wav

slug = sys.argv[1]
force = '--force' in sys.argv
ep = load_episode(slug)
V = {'id': 'TX3LPaxmHKxFdv7VOQHJ', 'model': 'eleven_multilingual_v2', 'settings': {'stability': 0.4, 'similarity_boost': 0.8, 'style': 0.35, 'use_speaker_boost': True}}
V.update(ep.get('voice', {}))
text = ' '.join(b['text'].strip() for b in ep['script'])
sig = hashlib.sha1(json.dumps([text, V], sort_keys=True).encode()).hexdigest()[:12]
raw_mp3 = pub_dir(slug) / 'voice_raw.wav'
raw_words = out_dir(slug) / 'words_raw.json'
meta = load_json(out_dir(slug) / 'voice_meta.json', {})

if force or meta.get('sig') != sig or not raw_mp3.exists() or not raw_words.exists():
    # OFFLINE VOICE: Kokoro (local neural TTS) replaces the ElevenLabs call. Same outputs: a raw take and word timings.
    import re as _re, soundfile as _sf
    from kokoro_onnx import Kokoro
    K = Kokoro('/home/claude/kokoro/kokoro.onnx', '/home/claude/kokoro/voices.bin')
    VOICE, SPEED = V.get('kokoro_voice', 'am_michael'), V.get('kokoro_speed', 1.06)
    sentences = [s for s in _re.findall(r'[^.!?]+[.!?]+', text)]
    audio, words, cur = [], [], 0.0
    PAD = int(0.30 * SR)
    for sent in sentences:
        sent = sent.strip()
        x, sr0 = K.create(sent, voice=VOICE, speed=SPEED, lang='en-us')
        x = np.interp(np.arange(0, len(x), sr0 / SR), np.arange(len(x)), x).astype(np.float64)
        # trim silence either side so word times are the voiced span
        a = np.abs(x); idx = np.where(a > 0.012 * a.max())[0]
        x = x[max(0, idx[0] - int(0.02 * SR)): idx[-1] + int(0.04 * SR)]
        toks = _re.findall(r"[\w'’]+[^\w\s'’]*", sent)
        # word weights from phoneme counts (+ a little for the word's punctuation pause)
        wts = []
        for tk in toks:
            ph = K.tokenizer.phonemize(_re.sub(r"[^\w'’]", '', tk), 'en-us')
            wts.append(max(2, len(ph)) + (3 if _re.search(r'[,.!?]', tk) else 0))
        tot = float(sum(wts)); dur = len(x) / SR
        t0 = 0.0
        for tk, wgt in zip(toks, wts):
            span = dur * wgt / tot
            pun = _re.sub(r"[\w'’]", '', tk)
            core = span - (dur * 3 / tot if pun and _re.search(r'[,.!?]', pun) else 0)
            words.append({'w': _re.sub(r"[^\w'’]", '', tk), 's': round(cur + t0, 3), 'e': round(cur + t0 + max(0.05, core), 3), 'p': pun})
            t0 += span
        padn = int((0.95 if sent.endswith('?') else 0.8) * SR)
        audio.append(x); audio.append(np.zeros(padn)); cur += dur + padn / SR
    y = np.concatenate(audio)
    write_wav(pub_dir(slug) / 'voice_raw.wav', y, 0.95)
    raw_mp3 = pub_dir(slug) / 'voice_raw.wav'
    save_json(raw_words, words)
    save_json(out_dir(slug) / 'voice_meta.json', {'sig': sig, 'chars': len(text), 'engine': 'kokoro-local'})
else:
    print('Voice unchanged since the last take: reusing it.')

# ---------------------------------------------------------------- tighten the pauses
words = load_json(raw_words)
G = {'word': 0.12, 'comma': 0.2, 'sentence': 0.3, 'question': 0.45, 'pairs': {}}
G.update(ep.get('gaps', {}))
x = decode(raw_mp3)
cuts = []


def bare(w):
    return re.sub(r'[^\w]', '', w)


for a, b in zip(words, words[1:]):
    gap = b['s'] - a['e']
    key = bare(a['w']) + '|' + bare(b['w'])
    if key in G['pairs']:
        keep = G['pairs'][key]
    elif '?' in a['p'] or '!' in a['p']:
        keep = G['question']
    elif '.' in a['p'] or ':' in a['p'] or ';' in a['p'] or '…' in a['p']:
        keep = G['sentence']
    elif ',' in a['p'] or '—' in a['p'] or '-' in a['p']:
        keep = G['comma']
    else:
        keep = G['word']
    if gap > keep:
        mid = (a['e'] + b['s']) / 2
        rm = gap - keep
        cuts.append((mid - rm / 2, mid + rm / 2))
parts, last = [], 0.0
for s, e in cuts:
    parts.append(x[int(last * SR):int(s * SR)])
    last = e
parts.append(x[int(last * SR):])
fade = int(0.004 * SR)  # a 4 ms fade either side of each join, so no click
for i, part in enumerate(parts):
    part = part.copy()
    if i > 0 and len(part) > fade:
        part[:fade] *= np.linspace(0, 1, fade)
    if i < len(parts) - 1 and len(part) > fade:
        part[-fade:] *= np.linspace(1, 0, fade)
    parts[i] = part
y = np.concatenate(parts)
write_wav(pub_dir(slug) / 'voice.wav', y)


def shift(t):
    return t - sum(min(e, t) - s for s, e in cuts if t > s)


out = [{'w': w['w'], 's': round(shift(w['s']), 3), 'e': round(shift(w['e']), 3), 'p': w.get('p', '')} for w in words]
save_json(ep_dir(slug) / 'words.json', out)
print(f'Tightened {len(cuts)} pauses, removed {sum(e - s for s, e in cuts):.2f} s: {len(x) / SR:.2f} s -> {len(y) / SR:.2f} s')
print(' '.join(f"{w['w']}@{w['s']}" for w in out))
