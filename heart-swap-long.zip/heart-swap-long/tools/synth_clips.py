# Offline stand-in for the five clips ElevenLabs would generate: synthesized with numpy, written to the sound library
# under the exact cache name (name + prompt + length), so sfx.py finds them and never calls the API.
import sys, json, subprocess, numpy as np
sys.path.insert(0, '/home/claude/what-if-animation/scripts')
from wi import SR, clip_path, write_wav, load_episode
rng = np.random.RandomState(7)
def env(n, a=0.01, d=6.0):
    t = np.linspace(0, 1, n); return np.minimum(t / a, 1) * np.exp(-t * d)
def thump(f, dur, g=1.0):
    n = int(dur * SR); t = np.arange(n) / SR
    return g * np.sin(2 * np.pi * (f * (1 - 0.35 * t / dur)) * t) * env(n, 0.02, 7)
def lowpass(x, k):
    return np.convolve(x, np.ones(k) / k, mode='same')
def heartbeat(secs):
    x = np.zeros(int(secs * SR))
    for t0, f, g in ((0.05, 62, 1.0), (0.30, 52, 0.7)):
        h = thump(f, 0.22, g); i = int(t0 * SR); x[i:i + len(h)] += h
    return x
def flutter(secs):
    n = int(secs * SR); t = np.arange(n) / SR
    am = (np.sin(2 * np.pi * 21 * t) > 0.2).astype(float)
    x = (np.sin(2 * np.pi * 70 * t) * 0.6 + lowpass(rng.randn(n), 40) * 3 * 0.3) * lowpass(am, 60)
    return x * np.minimum(t / 0.05, 1) * np.minimum((secs - t) / 0.2, 1)
def whale(secs):
    n = int(secs * SR); t = np.arange(n) / SR
    f = 95 + 70 * np.sin(np.pi * t / secs) ** 2 + 8 * np.sin(2 * np.pi * 0.9 * t)
    ph = np.cumsum(f) / SR
    x = np.sin(2 * np.pi * ph) + 0.5 * np.sin(4 * np.pi * ph) + 0.25 * np.sin(6 * np.pi * ph)
    return x * np.sin(np.pi * t / secs) ** 1.5
def run(secs):
    n = int(secs * SR); t = np.arange(n) / SR
    steps = np.zeros(n)
    for k in range(int(secs * 9)):
        i = int(k / 9 * SR + 0.05 * SR)
        if i + 800 < n: steps[i:i + 800] += lowpass(rng.randn(800), 8) * np.exp(-np.arange(800) / 150) * 0.9
    wind = lowpass(rng.randn(n), 30) * 4
    sw = np.sin(np.pi * t / secs) ** 2
    return steps + wind * sw * 0.35
def music(secs):
    n = int(secs * SR); t = np.arange(n) / SR
    bpm = 104; beat = 60 / bpm
    x = np.zeros(n)
    notes = [220.0, 261.63, 329.63, 293.66, 246.94, 329.63, 392.0, 329.63]
    for k in range(int(secs / (beat / 2))):
        t0 = k * beat / 2; f = notes[(k // 1) % len(notes)] * (1 if (k // 16) % 2 == 0 else 0.75)
        i = int(t0 * SR); m = int(0.28 * SR)
        if i + m >= n: break
        tt = np.arange(m) / SR
        x[i:i + m] += np.sin(2 * np.pi * f * tt) * np.exp(-tt * 14) * 0.35  # pizzicato
    for k in range(int(secs / beat)):
        i = int(k * beat * SR); h = thump(48, 0.3, 0.55) if k % 2 == 0 else thump(60, 0.2, 0.3)
        if i + len(h) < n: x[i:i + len(h)] += h
    pad = (np.sin(2 * np.pi * 110 * t) + 0.7 * np.sin(2 * np.pi * 164.81 * t) + 0.5 * np.sin(2 * np.pi * 130.81 * t)) * 0.11
    pad *= 0.5 + 0.5 * np.sin(2 * np.pi * t / 18 - 1.2) ** 2
    build = np.clip((t - 20) / 40, 0, 1)
    x = x * (0.55 + 0.5 * build) + pad * (0.8 + 0.8 * build)
    return x * np.minimum(t / 1.0, 1) * np.minimum((secs - t) / 1.0, 1)
def music_c(secs):
    n = int(secs * SR); t = np.arange(n) / SR
    x = np.zeros(n); bpm = 72; beat = 60 / bpm
    notes = [220.0, 246.94, 261.63, 329.63, 293.66, 246.94, 220.0, 196.0]
    for k in range(int(secs / (beat * 2))):
        i = int(k * beat * 2 * SR); f = notes[k % len(notes)]; m = int(0.9 * SR)
        if i + m >= n: break
        tt = np.arange(m) / SR; x[i:i + m] += np.sin(2 * np.pi * f * tt) * np.exp(-tt * 5) * 0.22
    pad = (np.sin(2 * np.pi * 110 * t) + 0.6 * np.sin(2 * np.pi * 164.81 * t) + 0.5 * np.sin(2 * np.pi * 130.81 * t)) * 0.12
    pad *= 0.55 + 0.45 * np.sin(2 * np.pi * t / 24) ** 2
    pulse = np.zeros(n)
    for k in range(int(secs / (beat * 2))):
        i = int(k * beat * 2 * SR); h = thump(46, 0.4, 0.35)
        if i + len(h) < n: pulse[i:i + len(h)] += h
    build = np.clip((t - 55) / 45, 0, 1)
    x = x * (0.8 + 0.5 * build) + pad * (0.9 + 0.8 * build) + pulse * (0.3 + 0.9 * build)
    return x * np.minimum(t / 2.0, 1) * np.minimum((secs - t) / 2.0, 1)
GEN = {'music_c': music_c, 'heartbeat': heartbeat, 'heart_flutter': flutter, 'whale_call': whale, 'run_whoosh': run, 'music_b': music}
for slug in ('heart-swap', 'heart-swap-long'):
  ep = load_episode(slug)
  for name, (prompt, secs) in ep['sound']['clips'].items():
      p = clip_path(name, prompt, secs)
      if p.exists() or name not in GEN: continue
      x = GEN[name](secs); wav = str(p) + '.tmp.wav'
      write_wav(wav, x, 0.9)
      subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-b:a', '128k', str(p)], check=True)
      import os; os.remove(wav); print('synthesized', name)
