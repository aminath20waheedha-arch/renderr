"""Mastering step (the same two-pass loudnorm the what-if-animation repo's master.py runs):
brings the mix to -14 LUFS with true peaks under -1.5 dBTP, video copied untouched.
usage: python finalize.py in.mp4 out.mp4"""
import json, subprocess, sys

src, dst = sys.argv[1], sys.argv[2]
I, TP, LRA = -14.0, -1.5, 11
first = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', src, '-af', f'loudnorm=I={I}:TP={TP}:LRA={LRA}:print_format=json', '-f', 'null', '-'],
                       capture_output=True, text=True, encoding='utf-8', errors='ignore').stderr
m = json.loads(first[first.rfind('{'):first.rfind('}') + 1])
filt = (f"loudnorm=I={I}:TP={TP}:LRA={LRA}:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}"
        f":measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', src, '-c:v', 'copy', '-af', filt, '-ar', '48000', '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', dst], check=True)
print('mastered ->', dst)
