import { loadFont } from "@remotion/fonts";
import { staticFile } from "remotion";

// Offline build: the same three faces (Bricolage Grotesque, Fragment Mono, Kalam), loaded from public/fonts
// (copied from the @fontsource packages) instead of Google Fonts, so rendering works without a connection.
const f = (family: string, file: string, weight: string) => loadFont({ family, url: staticFile("fonts/" + file), weight });
f("Bricolage Grotesque", "bricolage-grotesque-latin-700-normal.woff2", "700");
f("Bricolage Grotesque", "bricolage-grotesque-latin-800-normal.woff2", "800");
f("Fragment Mono", "fragment-mono-latin-400-normal.woff2", "400");
f("Kalam", "kalam-latin-400-normal.woff2", "400");
f("Kalam", "kalam-latin-700-normal.woff2", "700");

export const FONT = {
  title: "Bricolage Grotesque",
  ui: "Fragment Mono",
  hand: "Kalam",
};
