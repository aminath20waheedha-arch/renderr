import React from 'react';
import {
  Hero, Pose, basePose, poseAt, faceAt, kf, clamp, lerp, easeOut, easeIn, easeInOut, backOut, rnd, camT, shake, LOOKS, LEG_LEN, HEAD, joints, toWorld,
  Stairwell, Banister, hipGround, stepTop, walkPose, Rooftop, Kitchen, KitchenIsland, KITCHEN, stand, Bedroom, BEDROOM, bedSit, BedDuvet,
  Classroom, CLS, Schematic, SCH, SchLabel, CountUp, DrawOn, Foreground, Glow, Dust, Sparkle, PasteIn, TitleCard, Tag, FloatLabel, DizzyStars, FocusRings, WallCalendar, Mug, FONT,
  ShotProps,
} from '../../engine';

// "What if your heart swapped to a different animal's every day?" Twenty-three shots on six sets (stairwell,
// rooftop, kitchen, bedroom, classroom) and the schematic. The power: a HEART chip names the animal and a BPM
// readout runs while the swap is live; the new heart pops in with a ring (PasteIn), drawn by HeartShape below.
// Every shot is a pure function of its own clock t.

const PIP = LOOKS.pipHood;
const MO = LOOKS.mo;
const SIS = LOOKS.sis;
const SUIT = LOOKS.suit;
const TEAL = '#7DFFD0';
const VIOLET = '#B79BFF';
const AMBER = '#FFC46B';
const CYAN = '#7FD4FF';

// ---------------------------------------------------------------------------------------------------------------
// the heart prop, the week bar and the trace
// ---------------------------------------------------------------------------------------------------------------
export type Species = 'human' | 'hum' | 'chee' | 'octo' | 'whale';
const SPECIES: Record<Species, { fill: string; shade: string; glow: string; fpb: number; label: string; period: number }> = {
  human: { fill: '#FF5468', shade: '#C93049', glow: '#FF8A8A', fpb: 24, label: 'HUMAN', period: 190 },
  hum: { fill: '#FF6A7C', shade: '#D13A55', glow: TEAL, fpb: 3, label: 'HUMMINGBIRD', period: 26 },
  chee: { fill: '#F04A5C', shade: '#BC2C45', glow: AMBER, fpb: 8, label: 'CHEETAH', period: 70 },
  octo: { fill: '#8E6BFF', shade: '#5B3FC4', glow: VIOLET, fpb: 15, label: 'OCTOPUS', period: 150 },
  whale: { fill: '#C02C46', shade: '#8A1B33', glow: '#FF5A5A', fpb: 66, label: 'BLUE WHALE', period: 400 },
};
const beat = (t: number, fpb: number) => {
  const ph = (t / fpb) % 1;
  return Math.pow(Math.max(0, 1 - ph * 3.2), 2);
};

/** A cartoon heart in the world's flat-fill style: darker side away from the light, a warm highlight, two stubs on top. */
export const HeartShape: React.FC<{ x: number; y: number; s: number; kind?: Species; t?: number; id: string; glow?: number; fpb?: number }> = ({ x, y, s, kind = 'human', t = 0, id, glow = 1, fpb }) => {
  const K = SPECIES[kind];
  const p = beat(t, fpb ?? K.fpb);
  const sc = s * (1 + 0.11 * p);
  return (
    <g transform={`translate(${x} ${y})`}>
      <defs>
        <radialGradient id={`${id}g`}>
          <stop offset="0" stopColor={K.glow} stopOpacity={0.8} />
          <stop offset="1" stopColor={K.glow} stopOpacity={0} />
        </radialGradient>
        <clipPath id={`${id}c`}>
          <path d="M 0 0.95 C -1.25 0.1 -1.15 -0.95 -0.45 -0.95 C -0.15 -0.95 0 -0.75 0 -0.55 C 0 -0.75 0.15 -0.95 0.45 -0.95 C 1.15 -0.95 1.25 0.1 0 0.95 Z" transform={`scale(${sc})`} />
        </clipPath>
      </defs>
      <circle r={sc * 1.9} fill={`url(#${id}g)`} opacity={(0.45 + 0.45 * p) * glow} style={{ mixBlendMode: 'screen' }} />
      <g transform={`scale(${sc})`}>
        <rect x={-0.34} y={-1.28} width={0.24} height={0.5} rx={0.1} fill={K.shade} stroke="#2A0E16" strokeWidth={0.05} transform="rotate(-14 -0.22 -0.9)" />
        <rect x={0.08} y={-1.34} width={0.26} height={0.56} rx={0.11} fill={K.fill} stroke="#2A0E16" strokeWidth={0.05} transform="rotate(12 0.2 -0.9)" />
        <path d="M 0 0.95 C -1.25 0.1 -1.15 -0.95 -0.45 -0.95 C -0.15 -0.95 0 -0.75 0 -0.55 C 0 -0.75 0.15 -0.95 0.45 -0.95 C 1.15 -0.95 1.25 0.1 0 0.95 Z" fill={K.fill} />
      </g>
      <g clipPath={`url(#${id}c)`}>
        <rect x={sc * 0.18} y={-sc * 1.1} width={sc * 1.2} height={sc * 2.2} fill={K.shade} opacity={0.75} />
      </g>
      <g transform={`scale(${sc})`}>
        <path d="M 0 0.95 C -1.25 0.1 -1.15 -0.95 -0.45 -0.95 C -0.15 -0.95 0 -0.75 0 -0.55 C 0 -0.75 0.15 -0.95 0.45 -0.95 C 1.15 -0.95 1.25 0.1 0 0.95 Z" fill="none" stroke="#2A0E16" strokeWidth={0.06} strokeLinejoin="round" />
        <ellipse cx={-0.55} cy={-0.42} rx={0.2} ry={0.12} fill="#FFFFFF" opacity={0.5} transform="rotate(-30 -0.55 -0.42)" />
      </g>
    </g>
  );
};

/** A scrolling ECG strip: a spike every `period` px, running left. */
const Ecg: React.FC<{ x0: number; x1: number; y: number; t: number; kind: Species; h?: number; color?: string; speed?: number }> = ({ x0, x1, y, t, kind, h = 150, color = TEAL, speed = 11 }) => {
  const P = SPECIES[kind].period;
  const pts: string[] = [];
  for (let x = x0; x <= x1; x += 4) {
    const u = (((x + t * speed) % P) + P) % P;
    const q = u / P;
    let v = 0;
    if (q < 0.1) v = Math.sin((q / 0.1) * Math.PI) * 0.12;
    else if (q > 0.16 && q < 0.2) v = -((q - 0.16) / 0.04) * 0.2;
    else if (q >= 0.2 && q < 0.25) v = -0.2 + ((q - 0.2) / 0.05) * 1.2;
    else if (q >= 0.25 && q < 0.3) v = 1 - ((q - 0.25) / 0.05) * 1.35;
    else if (q >= 0.3 && q < 0.34) v = -0.35 + ((q - 0.3) / 0.04) * 0.35;
    else if (q > 0.46 && q < 0.62) v = Math.sin(((q - 0.46) / 0.16) * Math.PI) * 0.2;
    pts.push(`${x},${y - v * h}`);
  }
  return <polyline points={pts.join(' ')} fill="none" stroke={color} strokeWidth={6} strokeLinejoin="round" strokeLinecap="round" style={{ filter: `drop-shadow(0 0 12px ${color})` }} />;
};

/** The week on the screen's lower left: seven pills, the current day lit. */
const DAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
const WeekBar: React.FC<{ day: number; t: number; x?: number; y?: number }> = ({ day, t, x = 96, y = 1000 }) => {
  const pop = backOut(clamp(t / 8));
  return (
    <g transform={`translate(${x} ${y})`} opacity={clamp(t / 6)}>
      <rect x={-26} y={-44} width={7 * 62 + 4} height={88} rx={44} fill="#0B0A1A" opacity={0.55} />
      {DAYS.map((d, i) => {
        const on = i === day;
        const done = i < day;
        return (
          <g key={i} transform={`translate(${i * 62 + 6} 0) scale(${on ? pop : 1})`}>
            <circle r={24} fill={on ? '#FF8A3D' : done ? '#5A4E78' : 'none'} stroke={on ? '#FFE27A' : '#8C84A8'} strokeWidth={3} />
            <text y={11} textAnchor="middle" fontFamily={FONT.ui} fontSize={30} fill={on ? '#1A1230' : '#E7E0F0'}>
              {d}
            </text>
          </g>
        );
      })}
    </g>
  );
};

/** A running pose: the repo's walk cycle, opened up (bigger swing, pumping arms, a lean into it). */
const runPose = (x: number, phase: number, ground: number | ((x: number) => number), scale: number, extra: Partial<Pose> = {}): Pose => {
  const s = Math.sin(phase);
  return walkPose(x, phase, ground, scale, {
    tilt: 13,
    legL: { a: 46 * s, b: -Math.max(0, 78 * Math.sin(phase + 1.3)) },
    legR: { a: -46 * s, b: -Math.max(0, 78 * Math.sin(phase + 1.3 + Math.PI)) },
    armL: { a: -52 * s, b: 70 },
    armR: { a: 52 * s, b: 70 },
    ...extra,
  });
};

/** Pip's chest in world units, for a heart that sits on him. */
const chestOf = (pose: Pose) => toWorld(pose, { x: 4, y: -96 });

// ---------------------------------------------------------------------------------------------------------------
// the heart scope: an insert on the blueprint ground where a new heart pops in and the trace runs
// ---------------------------------------------------------------------------------------------------------------
const Scope: React.FC<{ t: number; kind: Species; id: string; count?: number; unit?: string; readout?: React.ReactNode; zoom?: number }> = ({ t, kind, id, count = 1, readout, zoom = 1 }) => {
  const K = SPECIES[kind];
  const xs = count === 1 ? [960] : count === 3 ? [610, 960, 1310] : [960];
  const size = count === 1 ? 210 : 130;
  return (
    <g transform={`translate(960 540) scale(${zoom}) translate(-960 -540)`}>
      <Schematic t={t} id={id} />
      <Glow x={960} y={470} r={620} kind="cool" o={0.25} />
      {xs.map((hx, i) => (
        <PasteIn key={i} x={hx} y={470} t={t - 4 - i * 6} color={K.glow} ring={size * 1.1}>
          <HeartShape x={hx} y={470} s={size} kind={kind} t={t + i * 4} id={`${id}h${i}`} />
        </PasteIn>
      ))}
      <Sparkle x={1180} y={330} t={t - 8} s={1.4} />
      <Ecg x0={120} x1={1800} y={880} t={t} kind={kind} />
      <SchLabel x={960} y={140} t={t - 3} text={`${K.label} HEART`} size={54} color={K.glow} />
      {readout}
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// MONDAY (hummingbird)
// ---------------------------------------------------------------------------------------------------------------
const SW_SC = 0.9;
const swWalk = (x: number, phase: number, extra: Partial<Pose> = {}) => runPose(x, phase, hipGround, SW_SC, extra);

// S1: wide, the foot of the stairs: the lit doorway above, Pip on the landing, ready
export const S1: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { ...walkPose(330, 0, hipGround, SW_SC), tilt: 0, yaw: 0.8, legL: { a: 2, b: 0 }, legR: { a: -2, b: 0 }, armL: { a: 8, b: 6 }, armR: { a: 8, b: 6 }, look: 0.9 } },
    { f: 12, p: { tilt: 8, squash: 0.05, armL: { a: -20, b: 30 }, armR: { a: 30, b: 30 } } },
    { f: 19, p: { tilt: 13 }, ease: easeOut },
  ]);
  return (
    <g>
      <g transform={camT(kf(t, [[0, 640], [len, 700]]), kf(t, [[0, 400], [len, 470]]), kf(t, [[0, 1.45], [len, 1.3]]))}>
        <Stairwell t={t} id="s1" />
        <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'happy']]) }} rimId="rimR" shadow={0.5} />
        <Banister />
      </g>
    </g>
  );
};

// S2: macro insert: a tiny hummingbird heart pops in and flutters
export const S2: React.FC<ShotProps> = ({ t, len }) => (
  <Scope
    t={t}
    kind="hum"
    id="s2"
    zoom={kf(t, [[0, 1], [len, 1.05]])}
    readout={
      <g>
        <CountUp x={960} y={1000} t={t - 8} to={1200} dur={22} size={110} color={TEAL} suffix=" BPM" />
      </g>
    }
  />
);

// S3: wide, follow: he bolts down all seven steps
export const S3: React.FC<ShotProps> = ({ t, len }) => {
  const px = lerp(300, 1420, easeInOut(clamp(t / (len - 3))));
  const pose = (tt: number): Pose => {
    const x = lerp(300, 1420, easeInOut(clamp(tt / (len - 3))));
    return { ...swWalk(x, tt * 0.95), ...faceAt(tt, [[0, 'happy']]) };
  };
  const p0 = pose(t);
  return (
    <g>
      <g transform={camT(clamp(px + 60, 760, 1160), 580, kf(t, [[0, 1.2], [len, 1.12]]))}>
        <Stairwell t={t + 20} id="s3" />
        {([] as number[]).map((lag, i) => (
          <g key={lag} opacity={0.16 + 0.1 * i} style={{ mixBlendMode: 'screen' }}>
            <Hero look={PIP} pose={pose(Math.max(0, t - lag))} rimId="rimR" shadow={0} />
          </g>
        ))}
        <Hero look={PIP} pose={p0} rimId="rimR" shadow={0.4} />
        <Banister />
        {([] as number[]).map((i) => (
          <line key={i} x1={px - 70 - i * 46 - (t % 4) * 6} y1={p0.y + 20 + i * 36} x2={px - 190 - i * 46 - (t % 4) * 6} y2={p0.y + 20 + i * 36} stroke="#FFF3DC" strokeWidth={5} opacity={0.45 - i * 0.08} strokeLinecap="round" />
        ))}
      </g>
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// TUESDAY (cheetah)
// ---------------------------------------------------------------------------------------------------------------
const ROOF = 840;
// S4: medium follow: he sprints along the roof at dusk, the strings of lights streaming
export const S4: React.FC<ShotProps> = ({ t, len }) => {
  const SC = 1.05;
  const x = lerp(260, 1650, easeInOut(clamp(t / (len - 2))));
  const pose = runPose(x, t * 1.05, ROOF, SC, { yaw: 1 });
  const camx = kf(t, [[0, 520], [len, 1380]]);
  return (
    <g>
      <g transform={camT(camx, 560, 1.55)}>
        <Rooftop t={t + 12} sunX={1100} sunY={640} />
        {([] as number[]).map((lag, i) => (
          <g key={lag} opacity={0.14 + 0.1 * i} style={{ mixBlendMode: 'screen' }}>
            <Hero look={PIP} pose={runPose(x - 18 * lag * 0.45, (t - lag) * 1.05, ROOF, SC, { yaw: 1 })} rimId="rimR" shadow={0} />
          </g>
        ))}
        <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'cool']]) }} rimId="rimR" shadow={0.5} />
        {([] as number[]).map((i) => (
          <line key={i} x1={x - 80 - i * 50 - (t % 3) * 9} y1={ROOF - 220 + i * 44} x2={x - 260 - i * 50 - (t % 3) * 9} y2={ROOF - 220 + i * 44} stroke="#FFF3DC" strokeWidth={5} opacity={0.42 - i * 0.05} strokeLinecap="round" />
        ))}
      </g>
    </g>
  );
};

// S5: low angle: he blurs past the camera, the lights swaying in his wake
export const S5: React.FC<ShotProps> = ({ t, len }) => {
  const x = kf(t, [[0, -380], [9, 960], [22, 2400]], (u) => u);
  const mb = Math.max(2, 34 - Math.abs(x - 960) / 24);
  const pose = runPose(x, t * 1.1, 905, 1.9, { yaw: 1, scale: 1.9 });
  const sway = Math.max(0, t - 8);
  return (
    <g>
      <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.06]]))}>
        <Rooftop t={t + 90} sunX={1250} sunY={560} low={260} />
        <defs>
          <filter id="s5mb" x="-50%" y="-20%" width="200%" height="140%">
            <feGaussianBlur stdDeviation={`${mb} 0`} />
          </filter>
        </defs>
        <g filter="url(#s5mb)">
          <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'cool']]) }} rimId="rimR" shadow={0} />
        </g>
        {t > 8 ? (
          <g opacity={clamp(1 - sway / 28)} style={{ mixBlendMode: 'screen' }}>
            {([] as number[]).map((i) => (
              <line key={i} x1={1500 - sway * 30 + i * 30} y1={450 + i * 62} x2={800 - sway * 30 + i * 30} y2={450 + i * 62} stroke="#FFF3DC" strokeWidth={6} opacity={0.35} strokeLinecap="round" />
            ))}
          </g>
        ) : null}
      </g>
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// WEDNESDAY (octopus)
// ---------------------------------------------------------------------------------------------------------------
const K_PIP = stand(KITCHEN, 0.34, 0.4);
const K_MO = stand(KITCHEN, 0.68, 0.4);
// S6: two-shot, the kitchen: Pip at the island, Mo opposite with a mug
export const S6: React.FC<ShotProps> = ({ t, len }) => {
  const pip = poseAt(t, [
    { f: 0, p: { x: K_PIP.x, y: K_PIP.y, scale: K_PIP.scale, yaw: 0.45, look: 0.5, armL: { a: 12, b: -6 }, armR: { a: 12, b: -6 } } },
    { f: 20, p: {} },
    { f: 27, p: { armR: { a: 150, b: 138 }, headTilt: -6, tilt: -3 }, ease: easeOut },
  ]);
  const mo = poseAt(t, [
    { f: 0, p: { x: K_MO.x, y: K_MO.y, scale: K_MO.scale, yaw: -0.45, look: -0.5, armL: { a: 12, b: -6 }, armR: { a: 40, b: 110 } } },
    { f: 18, p: { armR: { a: 70, b: 125 } }, ease: easeOut },
    { f: 36, p: { armR: { a: 20, b: 20 }, look: -0.9 }, ease: easeOut },
  ]);
  return (
    <g>
      <g transform={camT(kf(t, [[0, 1010], [len, 990]]), 600, kf(t, [[0, 1.4], [len, 1.52]]))}>
        <Kitchen t={t + 40} id="s6" />
        <Hero look={PIP} pose={{ ...pip, ...faceAt(t, [[0, 'happy'], [26, 'worried']]) }} rimId="rimR" shadow={0} />
        <Hero look={MO} pose={{ ...mo, ...faceAt(t, [[0, 'happy'], [38, 'neutral']]) }} rimId="rimL" shadow={0} />
        <KitchenIsland />
      </g>
    </g>
  );
};

// S7: macro insert: three blue-violet hearts pop in a row
export const S7: React.FC<ShotProps> = ({ t, len }) => (
  <Scope
    t={t}
    kind="octo"
    id="s7"
    count={3}
    zoom={kf(t, [[0, 1], [len, 1.06]])}
    readout={
      <g>
        <FloatLabel x={960} y={720} t={t - 14} text="×3" color={VIOLET} size={150} />
      </g>
    }
  />
);

// S8: close-up: Mo stares; Pip's chest glows violet, soft, in front of him
export const S8: React.FC<ShotProps> = ({ t, len }) => {
  const sc = 3.5 * (1 + 0.04 * clamp(t / len));
  const head = { x: 1250, y: 560 };
  const pose: Pose = { ...basePose, x: head.x, y: head.y - HEAD.y * sc, scale: sc, yaw: -0.25, look: -0.8, headTilt: kf(t, [[0, 0], [12, 6]]), ...faceAt(t, [[0, 'neutral'], [8, 'shock']]) };
  return (
    <g>
      <g filter="url(#blur16)">
        <g transform="translate(-520 -420) scale(1.55)">
          <Kitchen t={t + 150} id="s8" />
        </g>
      </g>
      <rect x={0} y={0} width={1920} height={1080} fill="#07040C" opacity={0.25} />
      <Hero look={MO} pose={pose} rimId="rimL" shadow={0} />
      <Foreground blur={10}>
        <path d="M -60 1100 Q -20 700 260 640 Q 560 600 700 760 Q 780 900 820 1100 Z" fill="#14121C" />
        {[0, 1, 2].map((i) => (
          <HeartShape key={i} x={240 + i * 150} y={820 - (i === 1 ? 30 : 0)} s={64} kind="octo" t={t + i * 4} id={`s8h${i}`} />
        ))}
      </Foreground>
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// THE PREMISE
// ---------------------------------------------------------------------------------------------------------------
// S9: the title, wide on the roof at dusk; a heart floats over him
export const S9: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 960, y: ROOF - LEG_LEN * 0.62, scale: 0.62, yaw: 0, armL: { a: 16, b: 6 }, armR: { a: 16, b: 6 }, look: 0 } },
    { f: 30, p: { armL: { a: 150, b: 10 }, armR: { a: 150, b: 10 } }, ease: easeOut },
  ]);
  const species: Species[] = [];
  return (
    <g transform={camT(960, 520, kf(t, [[0, 1.0], [len, 1.07]]))}>
      <Rooftop t={t} sunX={960} sunY={690 - 40 * easeOut(clamp(t / 40))} />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'happy'], [26, 'shock']]) }} rimId="rimR" shadow={0.6} />
      {species.map((k, i) => {
        const ang = t * 0.05 + (i * Math.PI) / 2;
        return <HeartShape key={k} x={960 + Math.cos(ang) * 250} y={520 + Math.sin(ang) * 40 - 20} s={30} kind={k} t={t + i * 5} id={`s9h${i}`} glow={0.8} />;
      })}
      <TitleCard t={t} lines={['WHAT IF YOUR HEART', 'SWAPPED ANIMALS DAILY?']} accent="ANIMALS" accentT={44} size={88} y={170} />
    </g>
  );
};

// S10: insert: the calendar, seven days, a cross and a heart for each
export const S10: React.FC<ShotProps> = ({ t, len }) => {
  const day = Math.min(7, Math.floor((t * 8) / len));
  const kinds: Species[] = ['hum', 'chee', 'octo', 'whale', 'hum', 'chee', 'octo'];
  return (
    <g transform={`translate(960 540) scale(${kf(t, [[0, 1], [len, 1.06]])}) translate(-960 -540)`}>
      <rect width={1920} height={1080} fill="#15101F" />
      <Glow x={960} y={380} r={820} kind="warm" o={0.35} />
      <WallCalendar x={960 - 300} y={40} w={600} crossed={day} drawing={((t * 8) / len) % 1} />
      {kinds.map((k, i) => (
        <g key={i} opacity={clamp((t - (i * len) / 8 - 2) / 6)}>
          <HeartShape x={290 + i * 223} y={955} s={40} kind={k} t={t + i * 3} id={`s10h${i}`} glow={0.6} />
          <text x={290 + i * 223} y={1030} textAnchor="middle" fontFamily={FONT.ui} fontSize={30} fill="#E7E0F0" opacity={0.8}>
            {DAYS[i]}
          </text>
        </g>
      ))}
    </g>
  );
};

// S11: medium: Pip by the bedroom window, a shrug
export const S11: React.FC<ShotProps> = ({ t, len }) => {
  const S = stand(BEDROOM, 0.7, 0.55);
  const pose = poseAt(t, [
    { f: 0, p: { x: S.x, y: S.y, scale: S.scale, yaw: 0.3, look: 0.4, armL: { a: 12, b: 6 }, armR: { a: 12, b: 6 } } },
    { f: 10, p: { armL: { a: 62, b: 46 }, armR: { a: 62, b: 46 }, headTilt: 7, squash: -0.03 }, ease: easeOut },
    { f: 24, p: { armL: { a: 56, b: 40 }, armR: { a: 56, b: 40 }, headTilt: 9 } },
  ]);
  return (
    <g transform={camT(kf(t, [[0, 1130], [len, 1110]]), 560, kf(t, [[0, 1.55], [len, 1.65]]))}>
      <Bedroom t={t + 50} id="s11" crossed={0} clock="23:40" />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'neutral'], [9, 'oops']]) }} rimId="rimR" shadow={0} />
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// THURSDAY (the fun)
// ---------------------------------------------------------------------------------------------------------------
// S12: wide, the classroom: arms up, the room cheering
export const S12: React.FC<ShotProps> = ({ t, len }) => {
  const S = stand(CLS, 0.5, 0.62);
  const pose = poseAt(t, [
    { f: 0, p: { x: S.x, y: S.y, scale: S.scale, yaw: 0, armL: { a: 14, b: 6 }, armR: { a: 14, b: 6 } } },
    { f: 6, p: { squash: 0.08 }, ease: easeOut },
    { f: 12, p: { squash: -0.1, y: S.y - 60, armL: { a: 155, b: 12 }, armR: { a: 155, b: 12 } }, ease: easeOut },
    { f: 20, p: { squash: 0.05, y: S.y, armL: { a: 150, b: 16 }, armR: { a: 150, b: 16 } } },
    { f: 26, p: { squash: 0 } },
  ]);
  return (
    <g>
      <g transform={camT(900, 520, kf(t, [[0, 1.05], [len, 1.14]]))}>
        <Classroom t={t + 20} laugh={1} id="s12" />
        <Hero look={PIP} pose={{ ...pose, y: pose.y + (t > 26 ? Math.sin(t / 9) * 4 : 0), ...faceAt(t, [[0, 'happy'], [12, 'smug']]) }} rimId="rimL" shadow={0.6} />
      </g>
    </g>
  );
};

// S13: medium: Mo fans out a handful of paper tickets
export const S13: React.FC<ShotProps> = ({ t, len }) => {
  const S = stand(CLS, 0.42, 0.7);
  const pose = poseAt(t, [
    { f: 0, p: { x: S.x, y: S.y, scale: S.scale, yaw: 0.35, look: 0.4, armL: { a: 12, b: 6 }, armR: { a: 40, b: 100 } } },
    { f: 12, p: { armR: { a: 140, b: 40 }, headTilt: -4 }, ease: easeOut },
    { f: 20, p: { armR: { a: 128, b: 52 } } },
  ]);
  const j = joints(pose);
  const h = toWorld(pose, j.armR.end);
  return (
    <g>
      <g transform={camT(kf(t, [[0, 880], [len, 920]]), 640, kf(t, [[0, 1.0], [len, 1.1]]))}>
        <Classroom t={t + 80} laugh={0} id="s13" />
        <Hero look={MO} pose={{ ...pose, ...faceAt(t, [[0, 'happy'], [14, 'smug']]) }} rimId="rimR" shadow={0} />
        <g transform={`translate(${h.x} ${h.y - 18})`}>
          {[-26, -13, 0, 13, 26].map((r, i) => (
            <g key={i} transform={`rotate(${r * easeOut(clamp((t - 12) / 8))} 0 24)`}>
              <rect x={-17} y={-52} width={34} height={64} rx={5} fill={['#E9C46A', '#F28C6A', '#7FD4FF', '#9BD3A8', '#E9C46A'][i]} stroke="#1A1622" strokeWidth={3} />
            </g>
          ))}
        </g>
        <Tag x={S.x + 210} y={S.y - 300} t={t - 14} text="$2" />
      </g>
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// FRIDAY (the turn)
// ---------------------------------------------------------------------------------------------------------------
// S14: medium, high: night; Pip jolts upright and clutches his chest; a teal heart flickers over it
export const S14: React.FC<ShotProps> = ({ t, len }) => {
  const B = bedSit(0.22);
  const pose = poseAt(t, [
    { f: 0, p: { x: B.x, y: B.y, scale: B.scale, yaw: 0.95, look: 0.5, tilt: -14, legL: { a: 82, b: -80 }, legR: { a: 82, b: -80 }, armL: { a: 12, b: 6 }, armR: { a: 12, b: 6 } } },
    { f: 8, p: { tilt: 8, squash: -0.04 }, ease: easeOut },
    { f: 14, p: { tilt: 2, armR: { a: 118, b: 135 }, headTilt: -6 }, ease: easeOut },
    { f: 24, p: { tilt: 5 } },
  ]);
  const c = chestOf(pose);
  return (
    <g>
      <g transform={camT(kf(t, [[0, 800], [len, 810]]), 540, kf(t, [[0, 2.1], [len, 2.3]]))}>
        <Bedroom t={t + 10} id="s14" duvet={false} clock="02:47" lamp={0} crossed={4} />
        <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'tired'], [9, 'shock']]) }} rimId="rimBlue" shadow={0} />
        <BedDuvet knees={0.5} />
        <g opacity={t > 10 ? 0.5 + 0.5 * rnd(Math.floor(t / 2), 4) : 0}>
          <HeartShape x={c.x} y={c.y} s={34 * pose.scale} kind="hum" t={t * 2} id="s14h" />
        </g>
      </g>
    </g>
  );
};

// S15: schematic: 1,200 BPM, counting up
export const S15: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={`translate(960 540) scale(${kf(t, [[0, 1], [len, 1.05]])}) translate(-960 -540)`}>
    <Schematic t={t + 30} id="s15" />
    <PasteIn x={560} y={440} t={t + 2} color={TEAL} ring={200}>
      <HeartShape x={560} y={440} s={150} kind="hum" t={t} id="s15h" />
    </PasteIn>
    <SchLabel x={560} y={660} t={t - 6} text="HUMMINGBIRD" size={44} color={TEAL} />
    <CountUp x={1250} y={470} t={t - 10} to={1200} dur={34} size={190} color={SCH.live} />
    <SchLabel x={1250} y={560} t={t - 14} text="BEATS A MINUTE" size={42} color={SCH.dim} />
    <SchLabel x={1250} y={680} t={t - 52} text="= 20 BEATS EVERY SECOND" size={44} />
    <Ecg x0={120} x1={1800} y={900} t={t} kind="hum" />
  </g>
);

// S16: schematic: the human range against 1,200
const AX0 = 200;
const AX1 = 1720;
const bx = (bpm: number) => AX0 + (bpm / 1200) * (AX1 - AX0);
export const S16: React.FC<ShotProps> = ({ t, len }) => {
  const run = easeOut(clamp((t - 36) / 34));
  return (
    <g transform={`translate(960 540) scale(${kf(t, [[0, 1], [len, 1.05]])}) translate(-960 -540)`}>
      <Schematic t={t + 70} id="s16" />
      <SchLabel x={960} y={170} t={t - 2} text="HEART RATE · BEATS A MINUTE" size={44} />
      <rect x={AX0} y={520} width={AX1 - AX0} height={10} rx={5} fill={SCH.dim} opacity={0.6} />
      {[0, 200, 400, 600, 800, 1000, 1200].map((v) => (
        <g key={v}>
          <rect x={bx(v) - 2} y={520} width={4} height={34} fill={SCH.dim} />
          <SchLabel x={bx(v)} y={610} t={t - 4} text={v.toLocaleString('en-US')} size={28} color={SCH.dim} />
        </g>
      ))}
      <rect x={bx(60)} y={496} width={bx(200) - bx(60)} height={58} rx={10} fill={CYAN} opacity={clamp((t - 8) / 6) * 0.95} />
      <SchLabel x={bx(130)} y={430} t={t - 10} text="HUMAN" size={44} color={CYAN} />
      <SchLabel x={bx(130)} y={380} t={t - 12} text="60–200" size={36} color={CYAN} />
      <g transform={`translate(${bx(130) + (bx(1200) - bx(130)) * run} 525)`} opacity={clamp((t - 34) / 4)}>
        <HeartShape x={0} y={-64} s={34} kind="hum" t={t * 2} id="s16h" />
        <path d="M 0 -26 L 0 -4" stroke={TEAL} strokeWidth={5} />
      </g>
      <SchLabel x={bx(1200) - 20} y={800} t={t - 62} text="HUMMINGBIRD · 1,200" size={44} color={TEAL} anchor="end" />
      <Tag x={1560} y={300} t={t - 80} text="REAL" mark="check" markT={10} w={170} />
    </g>
  );
};

// S17: wide, low: his body can't keep up: the knees go, dizzy stars, the red light
export const S17: React.FC<ShotProps> = ({ t, len }) => {
  const S = stand(BEDROOM, 0.5, 0.6);
  const pose = poseAt(t, [
    { f: 0, p: { x: S.x, y: S.y, scale: S.scale, yaw: 0, tilt: 0, armL: { a: 14, b: 6 }, armR: { a: 118, b: 135 } } },
    { f: 8, p: { tilt: 6, sway: 10, headTilt: 8 } },
    { f: 16, p: { tilt: -10, headTilt: -12, squash: 0.1, legL: { a: 10, b: -50 }, legR: { a: -8, b: -55 } } },
    { f: 26, p: { y: S.y + 70, spin: 75, tilt: 0, armL: { a: 60, b: 20 }, armR: { a: 80, b: 30 }, legL: { a: 40, b: -30 }, legR: { a: 20, b: -50 }, squash: 0 }, ease: easeIn },
    { f: 32, p: { y: S.y + 96, spin: 86 }, ease: easeOut },
  ]);
  const sh = shake(t, 26, 8, 14);
  const hd = toWorld(pose, { x: 0, y: -176 });
  return (
    <g transform={`translate(${sh.x} ${sh.y})`}>
      <g transform={camT(960, kf(t, [[0, 600], [len, 650]]), kf(t, [[0, 1.2], [len, 1.1]]))}>
        <Bedroom t={t + 100} id="s17" crossed={4} clock="02:49" lamp={0.4} veil={0.5} />
        <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'worried'], [12, 'dizzy']]) }} rimId="rimRed" shadow={0.3} />
        {t > 12 ? <DizzyStars x={hd.x} y={hd.y - 40} t={t - 12} /> : null}
      </g>
      <rect width={1920} height={1080} fill="#FF1133" opacity={0.1 + 0.1 * Math.sin(t * 0.9) * clamp(t / 10)} style={{ mixBlendMode: 'screen' }} />
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// THE MAN IN THE SUIT
// ---------------------------------------------------------------------------------------------------------------
const LANDING = 420;
const SUIT_X = 250;
// S18: medium wide: a man in a suit fills the lit doorway; Pip and Mo freeze on the stairs
export const S18: React.FC<ShotProps> = ({ t, len }) => {
  const suit = poseAt(t, [
    { f: 0, p: { x: SUIT_X - 40, y: LANDING - LEG_LEN * 0.95, scale: 0.95, yaw: 0.2, look: 0.5, armL: { a: 8, b: 6 }, armR: { a: 8, b: 6 } } },
    { f: 16, p: { x: SUIT_X + 10 }, ease: easeOut },
  ]);
  const step = (x: number, extra: Partial<Pose>): Pose => ({ ...walkPose(x, 0, hipGround, 0.9), tilt: 0, legL: { a: 4, b: 0 }, legR: { a: -4, b: 0 }, armL: { a: 10, b: 8 }, armR: { a: 10, b: 8 }, yaw: -0.55, look: -0.9, ...extra });
  return (
    <g transform={camT(kf(t, [[0, 640], [len, 620]]), 480, kf(t, [[0, 1.05], [len, 1.18]]))}>
      <Stairwell t={t + 60} id="s18" />
      <Glow x={SUIT_X} y={300} r={420} kind="warm" o={0.45} />
      <Hero look={SUIT} pose={{ ...suit, ...faceAt(t, [[0, 'neutral']]) }} rimId="rimR" shadow={0.5} />
      <Hero look={PIP} pose={{ ...step(760, {}), ...faceAt(t, [[0, 'neutral'], [18, 'shock']]) }} rimId="rimL" shadow={0.5} />
      <Hero look={MO} pose={{ ...step(900, {}), ...faceAt(t, [[0, 'neutral'], [20, 'shock']]) }} rimId="rimL" shadow={0.5} />
      <Banister />
    </g>
  );
};

// S19: close-up: the suit; a tablet in his hand tracing a pulse; Pip's glowing chest blurred in front
export const S19: React.FC<ShotProps> = ({ t, len }) => {
  const sc = 3.4 * (1 + 0.05 * clamp(t / len));
  const head = { x: 1180, y: 520 };
  const pose: Pose = { ...basePose, x: head.x, y: head.y - HEAD.y * sc, scale: sc, yaw: -0.2, look: -0.7, headTilt: kf(t, [[0, 0], [60, -4]]), ...faceAt(t, [[0, 'neutral'], [60, 'smug']]) };
  return (
    <g>
      <g filter="url(#blur16)">
        <g transform="translate(-600 -330) scale(1.9)">
          <Stairwell t={t + 120} id="s19" />
        </g>
      </g>
      <rect width={1920} height={1080} fill="#07040C" opacity={0.28} />
      <Hero look={SUIT} pose={pose} rimId="rimL" shadow={0} />
      {/* the tablet's glow on his face */}
      <Glow x={760} y={700} r={520} kind="cool" o={0.35} />
      <g transform={`translate(420 560) rotate(-8)`}>
        <rect x={0} y={0} width={620} height={420} rx={28} fill="#0F1624" stroke="#2A3550" strokeWidth={8} />
        <rect x={22} y={22} width={576} height={376} rx={14} fill="#0A1020" />
        <Ecg x0={40} x1={580} y={250} t={t} kind="hum" h={110} speed={6} />
        <text x={50} y={86} fontFamily={FONT.ui} fontSize={30} fill="#7E8DA6">
          SUBJECT · LIVE PULSE
        </text>
        <text x={50} y={360} fontFamily={FONT.ui} fontSize={64} fill={TEAL}>
          {Math.round(lerp(78, 1180, easeOut(clamp(t / 40)))).toLocaleString('en-US')}
        </text>
      </g>
      <Foreground blur={10}>
        <path d="M 1500 1100 Q 1560 780 1700 740 Q 1880 700 1960 860 L 1960 1100 Z" fill="#14121C" />
        <HeartShape x={1760} y={880} s={56} kind="hum" t={t * 2} id="s19h" />
      </Foreground>
    </g>
  );
};

// S20: schematic: a blue whale's heart: the readout slows to two
export const S20: React.FC<ShotProps> = ({ t, len }) => {
  const bpm = Math.round(lerp(37, 2, easeInOut(clamp((t - 14) / 56))));
  return (
    <g transform={`translate(960 540) scale(${kf(t, [[0, 1], [len, 1.05]])}) translate(-960 -540)`}>
      <Schematic t={t + 50} id="s20" />
      <DrawOn d="M 240 520 C 330 380 760 360 1010 450 C 1120 410 1230 360 1340 330 C 1320 420 1310 470 1340 560 C 1230 540 1120 510 1010 540 C 760 680 330 700 240 520 Z" t={t - 2} dur={24} color={SCH.line} width={6} />
      <DrawOn d="M 330 560 C 450 600 620 610 760 580" t={t - 12} dur={14} color={SCH.dim} width={4} />
      <PasteIn x={640} y={500} t={t - 16} color="#FF5A5A" ring={200}>
        <HeartShape x={640} y={500} s={110} kind="whale" t={t} id="s20h" />
      </PasteIn>
      <SchLabel x={960} y={140} t={t - 4} text="BLUE WHALE · DIVING" size={54} color="#FF8A8A" />
      <text x={1500} y={640} textAnchor="middle" fontFamily={FONT.ui} fontSize={220} fill={SCH.live} opacity={clamp((t - 14) / 6)} style={{ filter: `drop-shadow(0 0 16px ${SCH.glow}66)` }}>
        {bpm}
      </text>
      <SchLabel x={1500} y={740} t={t - 18} text="BEATS A MINUTE" size={42} color={SCH.dim} />
      <Ecg x0={120} x1={1800} y={920} t={t} kind="whale" color="#FF7A7A" speed={7} />
    </g>
  );
};

// ---------------------------------------------------------------------------------------------------------------
// SUNDAY NIGHT
// ---------------------------------------------------------------------------------------------------------------
// S21: medium: his little sister hugs him goodnight; the bedside clock at 11:58
export const S21: React.FC<ShotProps> = ({ t, len }) => {
  const P = stand(BEDROOM, 0.5, 0.58);
  const Sd = stand(BEDROOM, 0.63, 0.58, 0.44);
  const pip = poseAt(t, [
    { f: 0, p: { x: P.x, y: P.y, scale: P.scale, yaw: 0.35, look: 0.5, headTilt: 0, armL: { a: 12, b: 6 }, armR: { a: 12, b: 6 } } },
    { f: 30, p: { armL: { a: 38, b: 52 }, armR: { a: 38, b: 52 }, headTilt: 8, look: 0.9 }, ease: easeInOut },
  ]);
  const sis = poseAt(t, [
    { f: 0, p: { x: Sd.x + 90, y: Sd.y, scale: Sd.scale, yaw: -0.5, look: -0.5, armL: { a: 10, b: 6 }, armR: { a: 10, b: 6 } } },
    { f: 22, p: { x: Sd.x, armL: { a: 150, b: 20 }, armR: { a: 150, b: 20 } }, ease: easeOut },
  ]);
  return (
    <g>
      <g transform={camT(kf(t, [[0, 1010], [len, 980]]), 640, kf(t, [[0, 1.45], [len, 1.75]]))}>
        <Bedroom t={t + 200} id="s21" crossed={6} clock="23:58" lamp={0.8} />
        <Hero look={PIP} pose={{ ...pip, ...faceAt(t, [[0, 'worried'], [34, 'tired']]) }} rimId="rimR" shadow={0} />
        <Hero look={SIS} pose={{ ...sis, ...faceAt(t, [[0, 'happy'], [24, 'happy']]) }} rimId="rimL" shadow={0} />
      </g>
    </g>
  );
};

// S22: close-up: Pip, wet-eyed; his sister soft behind; the clock at 11:59 glowing
export const S22: React.FC<ShotProps> = ({ t, len }) => {
  const sc = 3.7 * (1 + 0.05 * clamp(t / len));
  const head = { x: 1050, y: 570 };
  const pose: Pose = { ...basePose, x: head.x, y: head.y - HEAD.y * sc, scale: sc, yaw: 0.2, look: -0.2, headTilt: kf(t, [[0, 0], [20, -5]]), ...faceAt(t, [[0, 'worried'], [22, 'tired']]) };
  return (
    <g>
      <g filter="url(#blur16)">
        <g transform="translate(-700 -480) scale(2)">
          <Bedroom t={t + 260} id="s22" crossed={6} clock="23:59" lamp={0.8} />
          <Hero look={SIS} pose={{ ...basePose, x: 1010, y: 520, scale: 0.6, yaw: -0.3, expr: 'happy' }} rimId="rimL" shadow={0} />
        </g>
      </g>
      <rect width={1920} height={1080} fill="#07040C" opacity={0.3} />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
    </g>
  );
};

// S23: wide: the city goes dark in a sweep; PART 1; four hearts and a question
export const S23: React.FC<ShotProps> = ({ t, len }) => {
  const red = easeOut(clamp(t / 20));
  const kinds: Species[] = ['hum', 'chee', 'octo', 'whale'];
  const pose = poseAt(t, [
    { f: 0, p: { x: 960, y: ROOF + 10 - LEG_LEN * 0.8, scale: 0.8, yaw: -0.1, look: -0.5, armL: { a: 14, b: 6 }, armR: { a: 14, b: 6 } } },
    { f: 40, p: { look: 0.3, headTilt: 3 } },
    { f: 90, p: { look: -0.2, headTilt: 0 } },
  ]);
  const qa = easeOut(clamp((t - 64) / 12));
  return (
    <g transform={camT(960, kf(t, [[0, 540], [len, 500]]), kf(t, [[0, 1.0], [len, 1.12]]))}>
      <Rooftop t={t + 230} sunX={1180} sunY={600} red={red} blackout={clamp((t - 6) / 46)} lightsOut={clamp((t - 56) / 24)} cityLit={2.6} />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'worried'], [30, 'shock']]) }} rimId="rimRed" shadow={0.4} />
      <g transform={`translate(960 270) scale(${backOut(clamp((t - 34) / 10))})`} opacity={clamp((t - 34) / 6)}>
        <text textAnchor="middle" fontFamily={FONT.title} fontWeight={700} fontSize={150} fill="#FF8A3D" stroke="#1A1230" strokeWidth={14} paintOrder="stroke" style={{ filter: 'drop-shadow(0 0 22px rgba(255,138,61,0.55))' }}>
          PART 1
        </text>
      </g>
      <g opacity={qa}>
        <text x={960} y={372} textAnchor="middle" fontFamily={FONT.ui} fontSize={44} fill="#F6EFE3" letterSpacing={6} stroke="#1A1230" strokeWidth={8} paintOrder="stroke">
          WHICH HEART WOULD YOU KEEP?
        </text>
        {kinds.map((k, i) => (
          <g key={k} transform={`translate(${960 + (i - 1.5) * 230} ${y0(i)})`}>
            <HeartShape x={0} y={0} s={46} kind={k} t={t + i * 5} id={`s23h${i}`} />
            <text y={86} textAnchor="middle" fontFamily={FONT.ui} fontSize={24} fill="#F6EFE3" stroke="#1A1230" strokeWidth={6} paintOrder="stroke">
              {SPECIES[k].label}
            </text>
          </g>
        ))}
      </g>
    </g>
  );
};
const y0 = (i: number) => 468 + (i % 2 ? 6 : 0);

// ===============================================================================================================
// THE LONG CUT: new and reworked shots (slower holds, fewer overlays)
// ===============================================================================================================
import { Study, Desk, Paper } from '../../engine';

/** Pip wakes in bed and clutches his chest. `clock` says what time it is; `heart` lights the chest. */
const wake = (clock: string, id: string, rim: string, heart: boolean): React.FC<ShotProps> => ({ t, len }) => {
  const B = bedSit(0.22);
  const pose = poseAt(t, [
    { f: 0, p: { x: B.x, y: B.y, scale: B.scale, yaw: 0.95, look: 0.5, tilt: -14, legL: { a: 82, b: -80 }, legR: { a: 82, b: -80 }, armL: { a: 12, b: 6 }, armR: { a: 12, b: 6 } } },
    { f: 22, p: { tilt: -10 } },
    { f: 34, p: { tilt: 8, squash: -0.04 }, ease: easeOut },
    { f: 44, p: { tilt: 2, armR: { a: 118, b: 135 }, headTilt: -6 }, ease: easeOut },
    { f: 60, p: { tilt: 5 } },
  ]);
  const c = chestOf(pose);
  return (
    <g transform={camT(kf(t, [[0, 800], [len, 815]]), 540, kf(t, [[0, 1.9], [len, 2.3]]))}>
      <Bedroom t={t + 10} id={id} duvet={false} clock={clock} lamp={0.7} crossed={0} />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'tired'], [36, 'shock']]) }} rimId={rim} shadow={0} />
      <BedDuvet knees={0.5} />
      {heart ? (
        <g opacity={t > 44 ? 0.55 + 0.45 * Math.sin(t * 0.5) ** 2 : 0}>
          <HeartShape x={c.x} y={c.y} s={30 * pose.scale} kind="hum" t={t * 2} id={`${id}h`} />
        </g>
      ) : null}
    </g>
  );
};
export const W1 = wake('06:12', 'w1', 'rimR', true);
export const W2 = wake('05:31', 'w2', 'rimBlue', true);

// N1: the kitchen: his little sister cheers him on, Pip pleased with himself
const KP = stand(KITCHEN, 0.4, 0.4);
const KS = stand(KITCHEN, 0.58, 0.4, 0.44);
export const N1: React.FC<ShotProps> = ({ t, len }) => {
  const pip = poseAt(t, [
    { f: 0, p: { x: KP.x, y: KP.y, scale: KP.scale, yaw: 0.35, look: 0.5, armL: { a: 30, b: 100 }, armR: { a: 30, b: 100 } } },
    { f: 30, p: { headTilt: -4, tilt: -2 }, ease: easeOut },
  ]);
  const bob = Math.abs(Math.sin(t / 8)) * 26;
  const sis = poseAt(t, [{ f: 0, p: { x: KS.x, y: KS.y, scale: KS.scale, yaw: -0.5, look: -0.6, armL: { a: 150, b: 14 }, armR: { a: 150, b: 14 } } }]);
  return (
    <g transform={camT(kf(t, [[0, 1000], [len, 1020]]), 610, kf(t, [[0, 1.45], [len, 1.6]]))}>
      <Kitchen t={t + 90} id="n1" />
      <Hero look={PIP} pose={{ ...pip, ...faceAt(t, [[0, 'smug']]) }} rimId="rimR" shadow={0} />
      <Hero look={SIS} pose={{ ...sis, y: sis.y - bob, squash: bob > 20 ? -0.06 : 0.04, ...faceAt(t, [[0, 'happy']]) }} rimId="rimL" shadow={0} />
      <KitchenIsland />
    </g>
  );
};

// N2: close-up: "your body was never built for this": Pip, worried, a teal flicker at his chest
export const N2: React.FC<ShotProps> = ({ t, len }) => {
  const sc = 3.6 * (1 + 0.05 * clamp(t / len));
  const head = { x: 980, y: 540 };
  const pose: Pose = { ...basePose, x: head.x, y: head.y - HEAD.y * sc, scale: sc, yaw: 0.1, look: 0.1, headTilt: kf(t, [[0, 0], [len, -6]]), ...faceAt(t, [[0, 'worried'], [Math.floor(len * 0.6), 'tired']]) };
  return (
    <g>
      <g filter="url(#blur16)">
        <g transform="translate(-700 -480) scale(2)">
          <Bedroom t={t + 300} id="n2" crossed={4} clock="05:40" lamp={0.6} />
        </g>
      </g>
      <rect width={1920} height={1080} fill="#07040C" opacity={0.3} />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Foreground blur={10}>
        <HeartShape x={1640} y={930} s={70} kind="hum" t={t * 2} id="n2h" glow={0.7} />
      </Foreground>
    </g>
  );
};

// N4: schematic: what a whale's two extremes would be in a human: 20, then 400
const HumanScaled: React.FC<{ t: number; len: number; to: number; from: number; id: string; kind: Species; fpb: number; label: string; real?: boolean }> = ({ t, len, to, from, id, kind, fpb, label, real }) => {
  const v = Math.round(lerp(from, to, easeInOut(clamp((t - 6) / (len * 0.6)))));
  return (
    <g transform={`translate(960 540) scale(${kf(t, [[0, 1], [len, 1.05]])}) translate(-960 -540)`}>
      <Schematic t={t + 40} id={id} />
      <SchLabel x={960} y={150} t={t - 2} text="A HUMAN, SCALED TO A BLUE WHALE" size={46} />
      <PasteIn x={600} y={500} t={t - 4} color="#FF8A8A" ring={190}>
        <HeartShape x={600} y={500} s={130} kind="human" t={t} id={`${id}h`} fpb={fpb} />
      </PasteIn>
      <text x={1290} y={560} textAnchor="middle" fontFamily={FONT.ui} fontSize={230} fill={SCH.live} style={{ filter: `drop-shadow(0 0 16px ${SCH.glow}66)` }}>
        {v}
      </text>
      <SchLabel x={1290} y={650} t={t - 8} text="BEATS A MINUTE" size={42} color={SCH.dim} />
      <SchLabel x={1290} y={730} t={t - 20} text={label} size={40} color="#FF8A8A" />
      <Ecg x0={120} x1={1800} y={920} t={t} kind={kind} color="#FF7A7A" speed={8} />
      {real ? <Tag x={1560} y={300} t={t - (len - 50)} text="REAL" mark="check" markT={10} w={170} /> : null}
    </g>
  );
};
export const N4a: React.FC<ShotProps> = ({ t, len }) => <HumanScaled t={t} len={len} from={70} to={20} id="n4a" kind="whale" fpb={70} label="THE LOW" />;
export const N4b: React.FC<ShotProps> = ({ t, len }) => <HumanScaled t={t} len={len} from={70} to={400} id="n4b" kind="chee" fpb={4} label="THE HIGH · NEITHER IS SURVIVABLE" real />;

// N5: night, in bed: Pip and his little sister; she falls asleep against his shoulder; slow push-in
export const N5: React.FC<ShotProps> = ({ t, len }) => {
  const P = bedSit(0.2);
  const Sd = bedSit(0.3);
  const sleep = clamp((t - 120) / 30);
  const pip = poseAt(t, [
    { f: 0, p: { x: P.x, y: P.y, scale: P.scale, yaw: 0.95, look: 0.6, tilt: -2, legL: { a: 82, b: -80 }, legR: { a: 82, b: -80 }, armL: { a: 12, b: 6 }, armR: { a: 12, b: 6 } } },
    { f: 100, p: { look: 0.1, headTilt: 3 } },
    { f: 150, p: { headTilt: 6, look: 0.2 } },
  ]);
  const sis: Pose = {
    ...basePose, x: Sd.x, y: Sd.y + 10, scale: Sd.scale * 0.72, yaw: 0.95, look: 0.4, tilt: -4 + 8 * sleep, headTilt: 12 * sleep,
    legL: { a: 82, b: -80 }, legR: { a: 82, b: -80 }, armL: { a: 12, b: 6 }, armR: { a: 12, b: 6 }, blink: sleep,
  };
  return (
    <g transform={camT(kf(t, [[0, 900], [len, 860]]), 560, kf(t, [[0, 1.5], [len, 2.15]]))}>
      <Bedroom t={t + 120} id="n5" duvet={false} clock="23:12" lamp={0.8} crossed={5} />
      <Hero look={PIP} pose={{ ...pip, ...faceAt(t, [[0, 'tired'], [60, 'worried']]) }} rimId="rimR" shadow={0} />
      <Hero look={SIS} pose={{ ...sis, ...faceAt(t, [[0, 'happy'], [120, 'neutral']]) }} rimId="rimR" shadow={0} />
      <BedDuvet knees={0.5} />
    </g>
  );
};

// N6a: the study: the man in the suit slides a paper across the desk; Pip a dark shape in front
export const N6a: React.FC<ShotProps> = ({ t, len }) => {
  const suit = poseAt(t, [
    { f: 0, p: { x: 960, y: 712, scale: 1, yaw: 0, look: 0, armL: { a: 10, b: 8 }, armR: { a: 20, b: 40 } } },
    { f: 40, p: { armR: { a: 40, b: 70 }, headTilt: -3 }, ease: easeOut },
    { f: 80, p: { armR: { a: 20, b: 30 } } },
  ]);
  const px = kf(t, [[30, 980], [90, 780]]);
  return (
    <g transform={camT(960, 590, kf(t, [[0, 1.55], [len, 1.75]]))}>
      <Study t={t + 160} id="n6a" />
      <Hero look={SUIT} pose={{ ...suit, ...faceAt(t, [[0, 'neutral'], [50, 'smug']]) }} rimId="rimR" shadow={0} />
      <Desk x0={560} x1={1360} y={700} lamp={false} />
      <g transform={`translate(${px} 692) rotate(-4)`} opacity={clamp((t - 24) / 6)}>
        <rect x={-110} y={-26} width={220} height={20} fill="#EDE6D6" stroke="#1A1622" strokeWidth={2} />
        <rect x={-70} y={-22} width={140} height={4} fill="#9A9486" />
        <HeartShape x={0} y={-16} s={9} kind="human" t={t} id="n6ah" glow={0.4} />
      </g>
      <Foreground blur={12}>
        <path d="M -40 1100 Q 20 760 240 700 Q 440 660 520 800 Q 560 940 600 1100 Z" fill="#14121C" />
      </Foreground>
    </g>
  );
};

// N6b: schematic: four hearts, and one by one every other heart is gone
export const N6b: React.FC<ShotProps> = ({ t, len }) => {
  const kinds: Species[] = ['hum', 'chee', 'octo', 'whale'];
  return (
    <g transform={`translate(960 540) scale(${kf(t, [[0, 1], [len, 1.05]])}) translate(-960 -540)`}>
      <Schematic t={t + 80} id="n6b" />
      <SchLabel x={960} y={150} t={t - 2} text="LOCK ONE · LOSE THE REST" size={50} />
      {kinds.map((k, i) => {
        const gone = clamp((t - 24 - i * 14) / 10);
        return (
          <g key={k} opacity={1 - gone} transform={`translate(0 ${gone * 30})`}>
            <HeartShape x={320 + i * 427} y={520} s={96} kind={k} t={t + i * 5} id={`n6b${i}`} />
            <SchLabel x={320 + i * 427} y={680} t={t - 4} text={SPECIES[k].label} size={32} color={SPECIES[k].glow} />
          </g>
        );
      })}
      <Ecg x0={120} x1={1800} y={900} t={t} kind="octo" color="#8FA2C8" speed={7} />
    </g>
  );
};
