import React from 'react';
import { defineEpisode, Timeline, LookDef, HudChip } from '../../engine';
import timeline from './timeline.json';
import * as SH from './shots';

// The long cut: the same power looks, quieter. A chip names the animal whose heart you are wearing; no dials.
const chip = (label: string, grade: (lv: number) => string): LookDef => ({ grade, Overlay: ({ f }) => <HudChip f={f} label={label} icon="dot" /> });
const hum = chip('HUMMINGBIRD', (lv) => `saturate(${1 + 0.08 * lv}) brightness(${1 + 0.02 * lv})`);
const chee = chip('CHEETAH', (lv) => `saturate(${1 + 0.1 * lv})`);
const octo = chip('OCTOPUS', (lv) => `hue-rotate(${10 * lv}deg)`);
const whale = chip('BLUE WHALE', (lv) => `saturate(${1 - 0.12 * lv})`);

export const heartSwapLong = defineEpisode('HeartSwapLong', {
  timeline: timeline as Timeline,
  shots: { W1: SH.W1, W2: SH.W2, N1: SH.N1, N2: SH.N2, N4a: SH.N4a, N4b: SH.N4b, N5: SH.N5, N6a: SH.N6a, N6b: SH.N6b,
    S1: SH.S1, S2: SH.S2, S3: SH.S3, S4: SH.S4, S5: SH.S5, S6: SH.S6, S7: SH.S7, S8: SH.S8, S9: SH.S9, S10: SH.S10, S11: SH.S11,
    S12: SH.S12, S13: SH.S13, S15: SH.S15, S16: SH.S16, S17: SH.S17, S18: SH.S18, S19: SH.S19, S20: SH.S20, S22: SH.S22, S23: SH.S23 },
  looks: { hum, chee, octo, whale },
});
