// The registry: add each new episode here (one import, one entry).
import { heartSwapLong } from './heart-swap-long';

export const EPISODES = [heartSwapLong];
