# What If Your Balance Was 100x Sharper? — aiTrends 2D Studio project

1. Put the contents of this zip in a GitHub repo (the `.github` folder and `aitrends-2d-studio` folder must be at the repo root).
2. Open the **Actions** tab, choose **Render What If Your Balance Was 100x Sharper**, press **Run workflow**.
   - Tick **preview** first for a 30-second test (a few minutes).
   - For the full video pick 1080p (best) or 720p (about 2x faster). A public repo gets 4-core runners; a private repo uses 2 cores, so use 720p there.
3. When it finishes, open the run and download the artifact **balance-100x-mp4** (a zip containing the MP4).

Project files: `aitrends-2d-studio/projects/balance-100x/` (story bible, `story/shots.json` = all timing, `scenes/` = cast, sets, shot templates, `input/` = script and your ElevenLabs voiceover).
