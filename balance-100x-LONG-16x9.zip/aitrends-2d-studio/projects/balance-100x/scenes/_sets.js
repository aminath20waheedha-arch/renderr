// _sets.js — reusable environments (underscore = not auto-loaded; imported by shots).
import { E, V, mood, layer, backdrop, rr, seg, circle, ring, poly, linGrad, radGrad, glow, alpha, shade, mix, rng } from '/engine/core.js';
import * as FX from '/engine/fx2d.js';

export const GY0 = () => E.H * V(0.8, 0.68);
const W3 = () => E.W * 3;
const floor = (g, GY, c1, c2, lines = true) => { g.fillStyle = linGrad(g, 0, GY, 0, GY + 520, [c1, c2]); g.fillRect(-E.W, GY, W3(), E.H * 2); if (lines) FX.floorLines(g, GY, GY + 600, 'rgba(0,0,0,.25)', 0.08); };
const wallFill = (g, GY, M, k = 0) => { g.fillStyle = linGrad(g, 0, -E.H, 0, GY, [M.dark, shade(M.wall, k)]); g.fillRect(-E.W, -E.H, W3(), GY + E.H); };
const duskWin = (g, x, y, w, h, M, seed = 4) => { g.fillStyle = linGrad(g, 0, y, 0, y + h, M.sky); g.fillRect(x, y, w, h); FX.sun(g, x + w * 0.5, y + h * 0.72, 46, '#fff7e6', M.key, 4); FX.skyline(g, { x, y: y + h, w, maxH: h * 0.55, color: alpha(shade(M.wall, -0.25), 0.8), windowColor: alpha(M.practical, 0.7), seed }); };

// ---- street at dusk (curb, houses, lamps) ----
export function street(g, t, cam, o = {}) {
  const M = mood(o.mood || 'dusk'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.12, (g) => { backdrop(g, M.sky); FX.sun(g, CX + V(520, 260), GY - V(520, 900), 62, '#fff3dc', M.key, 5); FX.clouds(g, { y: GY - V(850, 1400), h: 180, color: '#ffd9bd', a: 0.14, seed: 5 }); });
  layer(g, cam, 0.3, (g) => FX.skyline(g, { x: -E.W, y: GY - V(250, 420), w: W3(), minH: 80, maxH: V(260, 420), color: mix(M.sky[1], M.dark, 0.7), windowColor: alpha(M.practical, 0.5), lit: 0.2, seed: 8 }));
  layer(g, cam, 0.55, (g) => { for (let i = -5; i <= 5; i++) FX.facade(g, { x: CX + i * 520 - 260, y: GY - V(30, 50), w: 490, h: V(440, 660), color: shade(M.wall, -0.35 + ((i & 1) ? 0.08 : 0)), win: M.practical, dark: M.dark, cols: 3, rows: 3, lit: 0.5, seed: 20 + i }); });
  layer(g, cam, 0.9, (g) => {
    g.fillStyle = linGrad(g, 0, GY - 70, 0, GY, [shade(M.floor, 0.12), shade(M.floor, -0.05)]); g.fillRect(-E.W, GY - 70, W3(), 70);
    g.fillStyle = shade(M.floor, 0.4); g.fillRect(-E.W, GY - 3, W3(), 7);
    g.fillStyle = linGrad(g, 0, GY + 4, 0, GY + 500, [shade(M.dark, -0.1), shade(M.dark, -0.45)]); g.fillRect(-E.W, GY + 4, W3(), E.H * 2);
    for (const lx of [-760, 760]) { FX.lampPost(g, CX + lx, GY - 30, V(380, 440), { color: M.dark, light: M.practical }); FX.pool(g, CX + lx, GY + 8, 220, 30, M.practical, 0.25); }
  });
  return { GY, CX, M };
}
// ---- bus interior ----
export function bus(g, t, cam, o = {}) {
  const M = mood(o.mood || 'interiorCool'), GY = GY0(), CX = E.W / 2, dm = mood('dusk');
  layer(g, cam, 0.3, (g) => {
    wallFill(g, GY, M, 0.04);
    const wy = GY - V(580, 880), wh = V(270, 360);
    for (let i = -4; i <= 4; i++) { const wx = CX + i * 430 - 190; FX.windowFrame(g, { x: wx, y: wy, w: 380, h: wh, cols: 1, frame: shade(M.wall, -0.5), bar: 12 }, (g, x, y, w, h) => { g.fillStyle = linGrad(g, 0, y, 0, y + h, dm.sky); g.fillRect(x, y, w, h); FX.skyline(g, { x: x - ((t * 170) % 300) - 200, y: y + h, w: w + 800, minH: 60, maxH: h * 0.6, color: alpha(shade(dm.wall, -0.45), 0.92), windowColor: alpha(dm.practical, 0.85), lit: 0.3, seed: 3 }); }); }
    g.fillStyle = alpha(M.practical, 0.9); g.fillRect(-E.W, GY - V(930, 1420), W3(), 10); glow(g, CX, GY - V(925, 1415), 900, M.practical, 0.18);
    for (let i = -4; i <= 4; i++) { rr(g, CX + i * 430 - 150, GY - V(230, 330), 300, V(140, 190), 24); g.fillStyle = shade(M.wall, -0.45); g.fill(); }
  });
  layer(g, cam, 0.9, (g) => {
    floor(g, GY, shade(M.floor, 0.05), shade(M.dark, -0.2));
    seg(g, [[-E.W, GY - V(470, 740)], [E.W * 2, GY - V(470, 740)]], 9, shade(M.practical, -0.35));
    for (const px of [-0.28, 0.12, 0.5, 0.88]) { const x = E.W * (0.5 + px); seg(g, [[x, GY - V(470, 740)], [x, GY]], 9, shade(M.practical, -0.3)); seg(g, [[x - 2, GY - V(470, 740)], [x - 2, GY]], 2, alpha('#ffffff', 0.35)); }
  });
  return { GY, CX, M };
}
// ---- skate park at golden hour ----
export function skate(g, t, cam, o = {}) {
  const M = mood(o.mood || 'golden'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.12, (g) => { backdrop(g, M.sky); FX.sun(g, CX - V(420, 200), GY - V(420, 760), 78, '#fff3dc', M.key, 5); FX.clouds(g, { y: GY - V(800, 1300), h: 160, color: '#ffe7c7', a: 0.16, seed: 7 }); });
  layer(g, cam, 0.3, (g) => { FX.hills(g, { y: GY - V(160, 260), amp: 70, color: mix(M.sky[1], M.dark, 0.7), seed: 4 }); FX.skyline(g, { x: -E.W, y: GY - V(150, 240), w: W3(), minH: 40, maxH: 150, color: mix(M.sky[1], M.dark, 0.78), windowColor: alpha(M.practical, 0.4), lit: 0.1, seed: 12 }); });
  layer(g, cam, 0.6, (g) => { for (const x of [-1100, -500, 700, 1300, 1900]) FX.tree(g, CX + x - 700, GY - 20, 1.7, mix(M.dark, '#1c2a1c', 0.4)); for (const x of [-900, 900]) FX.lampPost(g, CX + x, GY - 10, V(520, 640), { color: M.dark, light: M.practical, a: 0.12 }); });
  layer(g, cam, 0.9, (g) => {
    floor(g, GY, shade(M.floor, 0.15), shade(M.dark, -0.1), false);
    const c = shade(M.floor, 0.22);
    poly(g, [[CX - 1000, GY], [CX - 1000, GY - 260], [CX - 880, GY - 255], [CX - 700, GY - 190], [CX - 520, GY - 60], [CX - 430, GY]], c);
    poly(g, [[CX + 1000, GY], [CX + 1000, GY - 220], [CX + 880, GY - 215], [CX + 720, GY - 160], [CX + 560, GY - 50], [CX + 480, GY]], c);
    seg(g, [[CX - 1000, GY - 260], [CX - 880, GY - 255], [CX - 700, GY - 190], [CX - 520, GY - 60]], 8, alpha(M.rim, 0.55));
    g.fillStyle = shade(M.floor, 0.3); g.fillRect(CX + 80, GY - 52, 320, 52); g.fillStyle = alpha(M.rim, 0.5); g.fillRect(CX + 80, GY - 52, 320, 5);
    FX.pool(g, CX - V(420, 200), GY + 20, 500, 40, M.key, 0.14);
  });
  return { GY, CX, M };
}
// ---- classroom ----
export function classroom(g, t, cam, o = {}) {
  const M = mood(o.mood || 'interiorWarm'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.35, (g) => {
    wallFill(g, GY, M);
    const wy = GY - V(620, 900), wh = V(360, 480);
    for (const x of [CX - 1120, CX + 520]) FX.windowFrame(g, { x, y: wy, w: 600, h: wh, cols: 3, frame: shade(M.wall, -0.55), bar: 10, blinds: 7 }, (g, x2, y2, w, h) => duskWin(g, x2, y2, w, h, M, 6));
    rr(g, CX - 380, GY - V(560, 840), 760, V(290, 380), 10); g.fillStyle = '#172620'; g.fill(); g.strokeStyle = shade(M.wall, -0.5); g.lineWidth = 12; g.stroke();
    g.strokeStyle = 'rgba(240,240,230,.5)'; g.lineWidth = 3; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(CX - 330, GY - V(500, 780) + i * 50); g.lineTo(CX - 330 + 200 + (i * 97) % 240, GY - V(500, 780) + i * 50); g.stroke(); }
    FX.clock(g, CX + 480, GY - V(770, 1120), 40, 8 * 3600 + 20 * 60 + t, { face: '#e9e2ea' });
  });
  layer(g, cam, 0.9, (g) => { floor(g, GY, shade(M.floor, 0.05), shade(M.dark, -0.2)); for (const x of [-0.18, 0.82]) { rr(g, E.W * x - 90, GY - 150, 260, 14, 6); g.fillStyle = shade(M.floor, 0.1); g.fill(); seg(g, [[E.W * x - 70, GY - 138], [E.W * x - 70, GY - 4]], 8, shade(M.floor, -0.2)); seg(g, [[E.W * x + 150, GY - 138], [E.W * x + 150, GY - 4]], 8, shade(M.floor, -0.2)); } FX.pool(g, CX - 600, GY + 24, 340, 40, M.key, 0.2); });
  return { GY, CX, M };
}
// ---- gym (balance beam) ----
export function gym(g, t, cam, o = {}) {
  const M = mood(o.mood || 'interiorCool'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.35, (g) => {
    wallFill(g, GY, M, 0.02);
    for (let i = -6; i <= 6; i++) { g.fillStyle = shade(M.wall, 0.12); g.fillRect(CX + i * 140 - 3, GY - V(560, 900), 6, V(540, 880)); }
    for (let k = 0; k < 9; k++) g.fillRect(-E.W, GY - V(560, 900) + k * V(70, 105), W3(), 4);
    for (const x of [-700, 0, 700]) { FX.lightCone(g, CX + x, GY - V(900, 1400), { angle: Math.PI / 2, spread: 0.5, len: V(900, 1300), color: M.key, a: 0.1 }); glow(g, CX + x, GY - V(900, 1400), 160, M.key, 0.5); }
  });
  layer(g, cam, 0.9, (g) => { floor(g, GY, mix(M.floor, '#7a5a3a', 0.45), shade(M.dark, -0.1)); const by = GY - V(125, 150); seg(g, [[CX - 760, by], [CX + 760, by]], 22, '#cdb48a'); seg(g, [[CX - 760, by - 8], [CX + 760, by - 8]], 5, alpha(M.rim, 0.7)); for (const x of [-560, 560]) { seg(g, [[CX + x, by + 8], [CX + x, GY]], 12, '#2b2230'); seg(g, [[CX + x - 40, GY], [CX + x + 40, GY]], 10, '#2b2230'); } FX.pool(g, CX, GY + 24, 700, 50, M.key, 0.12); });
  return { GY, CX, M, beamY: GY - V(125, 150) - 11 };
}
// ---- field with wire (golden hour) ----
export function field(g, t, cam, o = {}) {
  const M = mood(o.mood || 'golden'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.12, (g) => { backdrop(g, M.sky); FX.sun(g, CX + V(300, 200), GY - V(300, 560), 96, '#fff3dc', M.key, 5); FX.godRays(g, CX + V(300, 200), GY - V(300, 560), { count: 12, angle: -Math.PI / 2, spread: Math.PI * 1.4, len: 1800, a: 0.05, t }); FX.clouds(g, { y: GY - V(800, 1300), h: 150, color: '#ffe7c7', a: 0.16, seed: 9 }); });
  layer(g, cam, 0.3, (g) => FX.hills(g, { y: GY - V(130, 230), amp: 90, color: mix(M.sky[1], M.dark, 0.72), seed: 6 }));
  layer(g, cam, 0.6, (g) => { for (const x of [-1300, -700, 900, 1500]) FX.tree(g, CX + x, GY - 10, 2.0, mix(M.dark, '#1c2a1c', 0.45)); });
  layer(g, cam, 0.9, (g) => { g.fillStyle = linGrad(g, 0, GY - 40, 0, GY + 500, [mix(M.floor, '#3b4a2a', 0.5), shade(M.dark, -0.2)]); g.fillRect(-E.W, GY - 40, W3(), E.H * 2); for (let i = 0; i < 70; i++) { const x = -E.W + i * 80 + (i * 37) % 60; seg(g, [[x, GY + 30 + (i * 53) % 220], [x + 5, GY + 5 + (i * 53) % 220]], 3, alpha(M.rim, 0.14)); } FX.pool(g, CX, GY + 18, 700, 36, M.key, 0.14); });
  return { GY, CX, M };
}
// ---- ice rink ----
export function rink(g, t, cam, o = {}) {
  const M = mood(o.mood || 'interiorCool'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.35, (g) => { wallFill(g, GY - 60, M); for (let r = 0; r < 4; r++) { g.fillStyle = shade(M.wall, -0.15 - r * 0.05); g.fillRect(-E.W, GY - V(420, 650) + r * 52, W3(), 52); } FX.crowd(g, t, { seed: 5, x: -E.W * 0.2, y: GY - V(380, 600), w: E.W * 1.5, rows: 4, rowH: 52, size: 1.3, color: shade(M.wall, -0.5), flags: 0 }); for (const x of [-800, -200, 400, 1000]) { glow(g, CX + x, GY - V(900, 1400), 260, M.key, 0.5); FX.lightCone(g, CX + x, GY - V(900, 1400), { angle: Math.PI / 2, spread: 0.45, len: V(900, 1300), color: M.key, a: 0.1 }); } });
  layer(g, cam, 0.9, (g) => { g.fillStyle = linGrad(g, 0, GY - 60, 0, GY + 520, [shade(M.floor, 0.42), shade(M.floor, 0.16), shade(M.dark, 0.1)]); g.fillRect(-E.W, GY - 60, W3(), E.H * 2); g.fillStyle = shade(M.wall, 0.05); g.fillRect(-E.W, GY - 70, W3(), 14); g.fillStyle = alpha('#ffffff', 0.5); g.fillRect(-E.W, GY - 58, W3(), 3); for (let i = -4; i < 5; i++) seg(g, [[CX + i * 320, GY + 40], [CX + i * 320 + 160, GY + 120]], 2, alpha('#ffffff', 0.22)); });
  return { GY, CX, M };
}
// ---- clinic (Dr. Lee) ----
export function clinic(g, t, cam, o = {}) {
  const M = mood(o.mood || 'interiorWarm'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.35, (g) => {
    wallFill(g, GY, M);
    FX.windowFrame(g, { x: CX - 300, y: GY - V(600, 900), w: 600, h: V(340, 460), cols: 3, frame: shade(M.wall, -0.55), bar: 10, blinds: 6 }, (g, x, y, w, h) => duskWin(g, x, y, w, h, M, 9));
    rr(g, CX - V(900, 460), GY - V(560, 860), 200, 250, 10); g.fillStyle = '#1b1828'; g.fill(); const ic = '#cfc7dd'; ring(g, CX - V(800, 360), GY - V(430, 730), 62, 5, ic); ring(g, CX - V(800, 360), GY - V(430, 730), 36, 4, ic); ring(g, CX - V(800, 360), GY - V(430, 730), 14, 4, ic);
    FX.screen(g, { x: CX + V(520, 260), y: GY - V(520, 780), w: 300, h: 190 }, (g, x, y, w, h) => { g.strokeStyle = '#7fd0d6'; g.lineWidth = 4; g.beginPath(); for (let i = 0; i <= 60; i++) { const px = x + 14 + (i / 60) * (w - 28), py = y + h / 2 + Math.sin(i * 0.5 + t * 3) * 34 * Math.exp(-(((i - 30) / 18) ** 2)); i ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke(); });
  });
  layer(g, cam, 0.9, (g) => { floor(g, GY, shade(M.floor, 0.05), shade(M.dark, -0.2)); rr(g, CX + V(560, 330), GY - 130, 420, 130, 14); g.fillStyle = shade(M.wall, -0.2); g.fill(); g.fillStyle = alpha(M.rim, 0.5); g.fillRect(CX + V(560, 330), GY - 130, 420, 4); FX.pool(g, CX, GY + 24, 600, 40, M.key, 0.16); });
  return { GY, CX, M };
}
// ---- bedroom at night ----
export function bedroom(g, t, cam, o = {}) {
  const M = mood(o.mood || 'night'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.3, (g) => { wallFill(g, GY, M); FX.windowFrame(g, { x: CX + V(60, 20), y: GY - V(640, 940), w: 520, h: V(400, 520), cols: 2, rows: 2, frame: shade(M.wall, -0.55), bar: 12 }, (g, x, y, w, h) => { g.fillStyle = linGrad(g, 0, y, 0, y + h, M.sky); g.fillRect(x, y, w, h); FX.stars(g, t, { area: [x, y, w, h * 0.8], count: 40 }); FX.moon(g, x + w * 0.7, y + h * 0.3, 34); FX.skyline(g, { x, y: y + h, w, maxH: h * 0.3, color: alpha(M.dark, 0.9), windowColor: alpha(M.practical, 0.7), seed: 5 }); }); glow(g, CX + V(320, 280), GY - V(500, 780), 500, M.key, 0.1); });
  layer(g, cam, 0.9, (g) => { floor(g, GY, shade(M.floor, 0.06), shade(M.dark, -0.2)); FX.bed(g, { x: CX - V(780, 460), y: GY, w: 640, color: '#6a5aa6', frame: '#1e1830', pillow: '#d9d4ee' }); rr(g, CX - V(100, 0), GY - 110, 120, 110, 8); g.fillStyle = '#1e1830'; g.fill(); const lx = CX - V(40, 60); circle(g, lx, GY - 130, 20, M.practical); glow(g, lx, GY - 130, 300, M.practical, 0.45); FX.pool(g, lx, GY + 16, 300, 30, M.practical, 0.2); });
  return { GY, CX, M };
}
// ---- cafeteria ----
export function cafeteria(g, t, cam, o = {}) {
  const M = mood(o.mood || 'interiorWarm'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.35, (g) => { wallFill(g, GY, M); for (let i = -3; i <= 3; i++) FX.windowFrame(g, { x: CX + i * 520 - 200, y: GY - V(640, 940), w: 400, h: V(280, 380), cols: 2, frame: shade(M.wall, -0.55), bar: 10 }, (g, x, y, w, h) => duskWin(g, x, y, w, h, M, 30 + i)); FX.crowd(g, t, { seed: 14, x: -E.W * 0.2, y: GY - V(190, 300), w: E.W * 1.5, rows: 2, rowH: 40, size: 1.2, color: shade(M.wall, -0.55), flags: 0 }); });
  layer(g, cam, 0.9, (g) => { floor(g, GY, shade(M.floor, 0.1), shade(M.dark, -0.2)); for (const x of [-0.25, 0.3, 0.85]) { rr(g, E.W * x - 80, GY - 110, 520, 14, 6); g.fillStyle = shade(M.floor, 0.2); g.fill(); seg(g, [[E.W * x - 40, GY - 96], [E.W * x - 40, GY]], 8, shade(M.floor, -0.2)); seg(g, [[E.W * x + 360, GY - 96], [E.W * x + 360, GY]], 8, shade(M.floor, -0.2)); g.fillStyle = '#e2c39a'; g.fillRect(E.W * x + 40, GY - 118, 90, 8); g.fillRect(E.W * x + 230, GY - 118, 90, 8); } FX.pool(g, CX, GY + 24, 700, 40, M.key, 0.14); });
  return { GY, CX, M };
}
// ---- elevator ----
export function lift(g, t, cam, o = {}) {
  const M = mood(o.mood || 'interiorCool'), GY = GY0(), CX = E.W / 2;
  layer(g, cam, 0.5, (g) => { wallFill(g, GY, M, 0.1); g.fillStyle = shade(M.wall, 0.18); g.fillRect(CX - 360, GY - V(620, 940), 720, V(620, 940)); seg(g, [[CX, GY - V(620, 940)], [CX, GY]], 6, shade(M.wall, -0.4)); g.fillStyle = alpha(M.practical, 0.9); g.fillRect(-E.W, GY - V(930, 1420), W3(), 10); glow(g, CX, GY - V(925, 1415), 800, M.practical, 0.2); rr(g, CX + 440, GY - V(420, 640), 90, 220, 12); g.fillStyle = '#14141c'; g.fill(); for (let i = 0; i < 5; i++) circle(g, CX + 485, GY - V(385, 600) + i * 38, 9, i === 2 ? M.practical : '#5a5a70'); });
  layer(g, cam, 0.9, (g) => floor(g, GY, shade(M.floor, 0.05), shade(M.dark, -0.2)));
  return { GY, CX, M };
}
// ---- footbridge over the river at dusk (sway = horizontal offset of the deck layer) ----
export function bridge(g, t, cam, o = {}) {
  const M = mood(o.mood || 'dusk'), GY = GY0(), CX = E.W / 2, sw = o.sway || 0;
  layer(g, cam, 0.12, (g) => { backdrop(g, M.sky); FX.sun(g, CX + V(500, 240), GY - V(380, 700), 70, '#fff3dc', M.key, 5); FX.clouds(g, { y: GY - V(800, 1300), h: 170, color: '#ffd9bd', a: 0.15, seed: 12 }); });
  layer(g, cam, 0.3, (g) => FX.skyline(g, { x: -E.W, y: GY - V(130, 240), w: W3(), minH: 90, maxH: V(300, 460), color: mix(M.sky[1], M.dark, 0.72), windowColor: alpha(M.practical, 0.5), lit: 0.22, seed: 15 }));
  layer(g, cam, 0.6, (g) => { g.fillStyle = linGrad(g, 0, GY + 50, 0, GY + 700, [mix(M.sky[1], M.dark, 0.5), shade(M.dark, -0.3)]); g.fillRect(-E.W, GY + 50, W3(), E.H * 2); for (let i = 0; i < 24; i++) seg(g, [[CX - 1200 + i * 110 + Math.sin(t * 0.8 + i) * 20, GY + 90 + (i % 5) * 46], [CX - 1160 + i * 110 + Math.sin(t * 0.8 + i) * 20, GY + 90 + (i % 5) * 46]], 4, alpha(M.rim, 0.25)); });
  layer(g, { ...cam, x: (cam.x || 0) + sw, r: (cam.r || 0) }, 0.95, (g) => {
    g.fillStyle = shade(M.floor, 0.18); g.fillRect(-E.W, GY - 4, W3(), 60); g.fillStyle = shade(M.floor, 0.4); g.fillRect(-E.W, GY - 4, W3(), 5); g.fillStyle = shade(M.dark, -0.25); g.fillRect(-E.W, GY + 56, W3(), 22);
    for (let i = -10; i <= 10; i++) { const x = CX + i * 150; seg(g, [[x, GY - 4], [x, GY - V(190, 240)]], 6, shade(M.dark, -0.1)); }
    seg(g, [[-E.W, GY - V(190, 240)], [E.W * 2, GY - V(190, 240)]], 10, shade(M.floor, 0.3)); seg(g, [[-E.W, GY - V(95, 120)], [E.W * 2, GY - V(95, 120)]], 4, shade(M.dark, 0.1));
    for (const x of [-980, 980]) { seg(g, [[CX + x, GY], [CX + x, GY - V(760, 1000)]], 22, shade(M.dark, -0.15)); for (let k = 1; k <= 8; k++) seg(g, [[CX + x, GY - V(760, 1000)], [CX + x * (1 - k * 0.12), GY - V(190, 240)]], 2, alpha(M.rim, 0.35)); }
  });
  return { GY, CX, M };
}
export const SETS = { street, bus, skate, classroom, gym, field, rink, clinic, bedroom, cafeteria, lift, bridge };
