// _tpl.js — shot templates driven by story/shots.json `params` (tpl = wide | face | insert | diagram | card).
import { E, V, S, mood, layer, blurLayer, veil, backdrop, ease, prog, clamp, lerp, mix, alpha, shade, key, shake, talkAmount, wordTime, seg, circle, ring, rr, poly, glow, text, FONTS, linGrad } from '/engine/core.js';
import { drawFigure, POSES, posesAt, breathe, walkPose, bigFace } from '/engine/rig2d.js';
import * as FX from '/engine/fx2d.js';
import * as UI from '/engine/ui2d.js';
import { SETS, GY0 } from './_sets.js';
import { CAST } from './cast.js';

const iv = (a, k) => (Array.isArray(a) ? lerp(a[0], a[1], k) : a ?? 0);
const lt = (info, w, d = 0.3) => (typeof w === 'number' ? w : wordTime(w, info.shot.start) != null ? wordTime(w, info.shot.start) - info.shot.start : d);
export function camOf(p, t, dur) {
  const k = ease.inOut(clamp(t / dur)), c = p.cam || {}; let r = iv(c.r ?? 0, k);
  if (p.sway) r += p.sway.amp * Math.sin(t * p.sway.freq * 6.2832) * (p.sway.ramp ? 0.25 + 0.75 * clamp(t / dur) : 1);
  const [sx, sy] = p.shake ? shake(t, p.shake, 1.6) : [0, 0];
  return { z: iv(c.z ?? 1, k), x: iv(c.x ?? 0, k) + sx, y: iv(c.y ?? 0, k) + sy, r };
}
const rimOf = (M, dir = [0, -1]) => ({ color: M.rim, dir, w: 4 });
function atmos(g, t, p, M) {
  for (const f of p.fx || ['dust']) {
    if (f === 'dust') FX.dust(g, t, { count: 40, color: M.key, a: 0.35 });
    else if (f === 'rain') FX.rain(g, t, { count: 220 });
    else if (f === 'drops') FX.drops(g, t, { count: 60 });
    else if (f === 'stars') FX.stars(g, t, { count: 60 });
    else if (f === 'lens') FX.lensStreak(g, E.W / 2, E.H * 0.3, E.W * 1.2, M.key, 0.18);
    else if (f === 'speed') FX.speedLines(g, t, { count: 40, a: 0.18 });
  }
}
function overlays(g, t, info, p) {
  for (const u of p.ui || []) {
    const t0 = lt(info, u.at ?? u.word ?? 0.4), a = ease.out(prog(t, t0, t0 + 0.3)) * (u.until ? 1 - prog(t, u.until - 0.3, u.until) : 1); if (a <= 0) continue;
    if (u.k === 'readout') UI.readout(g, { label: u.label, value: u.value, x: u.x ?? V(140, 90), y: u.y ?? E.H - V(170, 620), a, color: u.color, align: u.align });
    else if (u.k === 'badge') UI.badge(g, { str: u.str, a });
    else if (u.k === 'label') text(g, u.str, u.x ?? E.W / 2, u.y ?? E.H * 0.2, { size: u.size ?? V(54, 56), color: u.color ?? S().ui.cream, glow: 18, glowColor: alpha(u.color ?? S().ui.gold, 0.6), alpha: a, spacing: 3 });
    else if (u.k === 'dim') UI.dimension(g, t, { x1: u.x1 * E.W, y1: u.y1 * E.H, x2: u.x2 * E.W, y2: u.y2 * E.H, str: u.str, start: t0 });
  }
}
// --- characters ---
function char(g, t, info, c, GY, M) {
  const k = ease.inOut(clamp(t / info.dur)), xs = Array.isArray(c.x) ? c.x : [c.x, c.x], x = lerp(xs[0], xs[1], c.walk ? clamp(t / info.dur) : k) * E.W;
  let pose; const seed = c.seed || 0;
  if (c.walk) pose = walkPose(t * Math.PI * 2 * (c.run ? 1.6 : 0.9) + seed, { run: !!c.run });
  else pose = breathe(posesAt(t, (c.poses || [[0, 'stand']]).map(([a, n]) => [a, typeof n === 'string' ? POSES[n] : n])), t, 1, seed);
  const rot = c.rot ? iv(c.rot, k) + (c.wob ? Math.sin(t * c.wob) * 0.03 : 0) : 0;
  drawFigure(g, { x, y: GY + (c.dy || 0), s: c.s || V(1.3, 1.5), facing: c.facing ?? 1, outfit: CAST[c.id], pose, expr: c.expr || 'neutral', look: c.look, talk: c.talk ? talkAmount(info.globalT, info.shot.start, info.shot.end) : 0, rim: rimOf(M, c.rimdir), prop: c.prop, rot, blink: (t % (3 + 0.37 * seed)) > 2.9 + 0.37 * seed * 0, trail: c.trail, alpha: c.alpha });
}
// --- wide / medium shot in a set ---
function wide(g, t, info, p) {
  const cam = camOf(p, t, info.dur), setF = SETS[p.set], M = mood(p.mood || 'dusk');
  const sw = p.deckSway ? p.deckSway.amp * Math.sin(t * p.deckSway.freq * 6.2832) * (p.deckSway.decay ? 1 - 0.95 * ease.inOut(t / info.dur) : 0.25 + 0.75 * clamp(t / info.dur)) : 0;
  const { GY } = setF(g, t, cam, { mood: p.mood, sway: sw });
  const MM = mood(p.mood || ({ bus: 'interiorCool', classroom: 'interiorWarm', gym: 'interiorCool', rink: 'interiorCool', clinic: 'interiorWarm', cafeteria: 'interiorWarm', lift: 'interiorCool', bedroom: 'night', skate: 'golden', field: 'golden' }[p.set] || 'dusk'));
  layer(g, cam, 1, (g) => {
    if (p.crowd) FX.crowd(g, t, { seed: 31, x: E.W * 0.05, y: GY - 6, w: E.W * 0.9, rows: p.crowd.rows || 2, rowH: 34, size: p.crowd.size || 2.4, color: shade(MM.dark, 0.05), flags: 0, cheer: p.crowd.cheer || 0 });
    for (const c of p.chars || []) char(g, t, info, c, GY, MM);
    if (p.extra) EXTRA[p.extra]?.(g, t, info, GY, MM, p);
  });
  if (p.fg) blurLayer(g, 10, (g) => { for (const f of p.fg) { const x = f.x * E.W; seg(g, [[x, GY - V(220, 300)], [x, E.H + 50]], f.w || 60, alpha(MM.dark, 0.9)); } }, cam, 1.7);
  atmos(g, t, p, MM); if (p.tint) veil(g, p.tint[0], p.tint[1]); overlays(g, t, info, p);
}
// props used as `extra`
const EXTRA = {
  coffee: (g, t, info, GY) => { const x = E.W * 0.5, y = GY - V(220, 300), r = Math.sin(t * 9) * 0.0; rr(g, x - 20, y - 36, 40, 36, 6); g.fillStyle = '#f2ece4'; g.fill(); seg(g, [[x + 20, y - 28], [x + 32, y - 20], [x + 20, y - 10]], 5, '#f2ece4'); g.fillStyle = '#4a2a1a'; g.fillRect(x - 17, y - 36, 34, 6); },
  bench: (g, t, info, GY, M) => { rr(g, E.W * 0.5 - 150, GY - 66, 300, 16, 6); g.fillStyle = shade(M.floor, 0.3); g.fill(); seg(g, [[E.W * 0.5 - 120, GY - 52], [E.W * 0.5 - 120, GY]], 8, shade(M.floor, 0.1)); seg(g, [[E.W * 0.5 + 120, GY - 52], [E.W * 0.5 + 120, GY]], 8, shade(M.floor, 0.1)); },
  pizza: (g, t, info, GY) => { const x = E.W * 0.5, y = GY - V(240, 320); poly(g, [[x - 40, y - 40], [x + 40, y - 30], [x, y + 36]], '#e8b050'); circle(g, x - 14, y - 22, 7, '#c63a2a'); circle(g, x + 12, y - 12, 6, '#c63a2a'); },
};
// --- giant face close-up ---
function face(g, t, info, p) {
  const M = mood(p.mood || 'dusk'), k = ease.inOut(clamp(t / info.dur)), set = SETS[p.set || 'street'];
  const rock = p.sway ? p.sway.amp * Math.sin(t * p.sway.freq * 6.2832) : 0;
  blurLayer(g, 14, (g) => set(g, t, { z: 1.5, x: -120, y: -100, r: rock }, { mood: p.mood }));
  veil(g, '#120a10', 0.35);
  const r = V(300, 330) * (1 + 0.05 * k);
  bigFace(g, E.W / 2 + (p.dx || 0), E.H * V(0.62, 0.56), r, { outfit: CAST[p.who], expr: p.expr || 'neutral', talk: p.talk ? talkAmount(info.globalT, info.shot.start, info.shot.end) : 0, look: p.look || [0, 0], rimColor: M.rim, rimSide: p.rimSide ?? -1, tilt: (p.tilt || 0) + (p.wob ? Math.sin(t * p.wob) * 0.025 : 0), blink: (t % 3.1) > 3.0 });
  if (p.rings) FX.rings(g, E.W / 2 + (p.dx || 0), E.H * 0.38, t, { count: 3, r0: 80, r1: 360, a: 0.35 });
  atmos(g, t, p, M); if (p.tint) veil(g, p.tint[0], p.tint[1]); overlays(g, t, info, p);
}
// --- inserts ---
const ink = () => S().ink;
function bgBlur(g, t, p, amt = 16, camx = 1.7) { const rock = p.rock ? p.rock * Math.sin(t * 5) : 0; blurLayer(g, amt, (g) => SETS[p.set || 'street'](g, t, { z: camx, x: 60, y: -40, r: rock }, { mood: p.mood }));  veil(g, '#120a10', 0.3); }
const INSERT = {
  coffee(g, t, info, p) { // cup stays dead level while the world rocks behind it
    bgBlur(g, t, { ...p, rock: p.rock ?? 0.05 }); const M = mood(p.mood || 'interiorCool'); const x = E.W / 2, y = E.H * 0.66, s = V(2.4, 2.6);
    g.save(); g.translate(x, y); g.scale(s, s); rr(g, -50, -90, 100, 92, 12); g.fillStyle = '#f2ece4'; g.fill(); seg(g, [[50, -72], [82, -52], [50, -26]], 12, '#f2ece4'); g.fillStyle = '#4a2a1a'; g.beginPath(); g.ellipse(0, -90, 50, 9, 0, 0, 7); g.fill(); g.fillStyle = 'rgba(0,0,0,.18)'; g.fillRect(16, -86, 34, 84); g.restore();
    for (let i = 0; i < 3; i++) { g.strokeStyle = alpha('#ffffff', 0.25); g.lineWidth = 6; g.lineCap = 'round'; g.beginPath(); for (let k = 0; k <= 20; k++) { const yy = y - 250 * s / 2.4 - k * 12, xx = x - 30 + i * 30 + Math.sin(t * 2 + k * 0.5 + i) * 14; k ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.stroke(); }
    FX.dust(g, t, { count: 30, color: M.key }); overlays(g, t, info, p);
  },
  feet(g, t, info, p) { // two feet planted on a line (beam / wire / curb)
    bgBlur(g, t, p, 14, 1.6); const M = mood(p.mood || 'dusk'); const y = E.H * 0.7, sway = Math.sin(t * 1.6) * 6 * (p.wobble ?? 1);
    const surf = p.surface || 'beam', th = surf === 'wire' ? 8 : surf === 'curb' ? 60 : 44;
    if (surf !== 'wire') { g.fillStyle = surf === 'curb' ? shade(M.floor, 0.3) : '#cdb48a'; g.fillRect(-E.W, y, E.W * 3, th); g.fillStyle = alpha(M.rim, 0.7); g.fillRect(-E.W, y, E.W * 3, 5); } else { seg(g, [[-E.W, y + 4], [E.W * 2, y + 4]], 8, '#cdd2da'); }
    const spread = p.spread ?? 150; for (const [i, dx] of [[0, -spread / 2], [1, spread / 2]]) { const fx = E.W / 2 + dx + (p.walk ? Math.sin(t * 4 + i * 3) * 24 : 0); seg(g, [[fx - 55, y - 14], [fx + 70, y - 14]], 36, ink()); seg(g, [[fx - 20 + sway * 0.2, y - 20], [fx - 28 + sway, -40]], 44, i ? ink() : S().inkFar); seg(g, [[fx - 55, y - 28], [fx + 70, y - 28]], 4, alpha(M.rim, 0.6)); }
    FX.dust(g, t, { count: 30, color: M.key }); overlays(g, t, info, p);
  },
  desk(g, t, info, p) { // desk on uneven legs, then a folded paper shim
    const M = mood('interiorWarm'); backdrop(g, [shade(M.wall, 0.05), shade(M.dark, 0.1)]); const GY = E.H * 0.82; const tFix = p.fixAt ?? 99, fixed = t > tFix;
    const rock = fixed ? 0 : Math.sin(t * 7) * 0.035 * Math.exp(-0.1 * t); const cx = E.W / 2; g.save(); g.translate(cx, GY); g.rotate(rock);
    rr(g, -460, -420, 920, 40, 12); g.fillStyle = '#b8946a'; g.fill(); g.fillStyle = alpha(M.rim, 0.6); g.fillRect(-440, -420, 880, 5);
    for (const [x, h] of [[-400, 380], [400, fixed ? 380 : 340]]) seg(g, [[x, -380], [x, -380 + h]], 26, '#8a6a48'); g.restore();
    g.fillStyle = '#efe9dc'; if (t > tFix - 0.5) { const k = ease.out(prog(t, tFix - 0.5, tFix)); g.save(); g.translate(cx + 400, GY - 20 + (1 - k) * -100); g.rotate(0.2 * (1 - k)); g.fillRect(-26, -20, 52, 24); g.restore(); }
    floorLine(g, GY, M); FX.dust(g, t, { count: 30, color: M.key }); overlays(g, t, info, p);
  },
  board(g, t, info, p) { // skateboard rolling, feet perfectly still
    bgBlur(g, t, { ...p, set: 'skate' }, 10, 1.4); const M = mood('golden'); const y = E.H * 0.72, x = E.W / 2;
    g.fillStyle = shade(M.floor, 0.2); g.fillRect(-E.W, y + 60, E.W * 3, 600); for (let i = 0; i < 14; i++) { const lx = ((i * 220 - t * 500) % (E.W + 300)) - 150; seg(g, [[lx, y + 120 + (i % 3) * 36], [lx + 120, y + 120 + (i % 3) * 36]], 3, alpha(M.rim, 0.25)); }
    rr(g, x - 300, y, 600, 26, 13); g.fillStyle = '#d64a33'; g.fill(); for (const dx of [-190, 190]) { circle(g, x + dx, y + 54, 34, '#e8e2d4'); circle(g, x + dx, y + 54, 12, '#2b2230'); const a = t * 14; seg(g, [[x + dx, y + 54], [x + dx + Math.cos(a) * 28, y + 54 + Math.sin(a) * 28]], 4, '#2b2230'); }
    for (const [i, dx] of [[0, -90], [1, 90]]) { seg(g, [[x + dx - 40, y - 12], [x + dx + 70, y - 12]], 40, ink()); seg(g, [[x + dx - 10, y - 20], [x + dx - 10, -60]], 46, i ? ink() : S().inkFar); seg(g, [[x + dx - 40, y - 28], [x + dx + 70, y - 28]], 4, alpha(M.rim, 0.6)); }
    FX.dust(g, t, { count: 30, color: M.key }); overlays(g, t, info, p);
  },
  clip(g, t, info, p) { // clipboard falls and bounces
    bgBlur(g, t, { ...p, set: 'gym' }, 14, 1.6); const M = mood('interiorCool'); const fall = Math.max(0, t - 0.2), y = E.H * 0.18 + Math.min(fall * fall * 1500, E.H * 0.5); const bounce = fall * fall * 1500 > E.H * 0.5 ? -Math.abs(Math.sin((t - 0.9) * 6)) * 80 * Math.exp(-(t - 0.9) * 2) : 0;
    g.save(); g.translate(E.W / 2, y + bounce); g.rotate(0.25 + fall * 2.2 * (y < E.H * 0.68 ? 1 : 0)); rr(g, -150, -210, 300, 420, 18); g.fillStyle = '#8a6a44'; g.fill(); g.fillStyle = '#efe9dc'; g.fillRect(-120, -170, 240, 350); rr(g, -50, -230, 100, 40, 10); g.fillStyle = '#b0b0b8'; g.fill(); for (let i = 0; i < 6; i++) g.fillRect(-100, -130 + i * 50, 180 - (i % 3) * 30, 6); g.restore();
    if (t > 0.9) FX.rings(g, E.W / 2, E.H * 0.72, t - 0.9, { count: 2, r0: 30, r1: 260, a: 0.4 }); FX.dust(g, t, { count: 30, color: M.key }); overlays(g, t, info, p);
  },
  bike(g, t, info, p) { // Mia on her bike, Leo's hand lets go
    const M = mood('golden'); blurLayer(g, 8, (g) => SETS.street(g, t, { z: 1.2, x: 60 - t * 40 }, { mood: 'golden' })); veil(g, '#120a10', 0.15);
    const GY = E.H * 0.82, x = E.W / 2 + 40, wob = Math.sin(t * 5) * 0.05 * Math.exp(-0.6 * t) * (p.wobble ?? 1);
    g.save(); g.translate(x, GY); g.rotate(wob); g.scale(1.6, 1.6);
    for (const dx of [-170, 170]) { ring(g, dx, -70, 70, 9, '#1a1420'); for (let k = 0; k < 8; k++) { const a = t * 9 + k * 0.785; seg(g, [[dx, -70], [dx + Math.cos(a) * 66, -70 + Math.sin(a) * 66]], 2, alpha('#ffffff', 0.35)); } }
    seg(g, [[-170, -70], [-40, -150], [150, -150], [170, -70]], 9, '#d64a33'); seg(g, [[-40, -150], [40, -70], [-170, -70]], 9, '#d64a33'); seg(g, [[-50, -165], [-10, -165]], 14, '#1a1420'); seg(g, [[140, -150], [150, -220]], 9, '#1a1420');
    drawFigure(g, { x: -20, y: -92, s: 1.55, facing: 1, outfit: CAST.mia, pose: POSES.sit, expr: t > 1.4 ? 'joy' : 'nervous', rim: rimOf(M), shadow: false, blink: (t % 3) > 2.9 });
    g.restore(); const hx = x - 190 - Math.max(0, t - 1) * 360, hy = GY - 250; seg(g, [[hx - 400, hy + 40], [hx, hy]], 46, ink()); circle(g, hx, hy, 36, ink()); seg(g, [[hx - 400, hy + 18], [hx - 4, hy - 20]], 4, alpha(M.rim, 0.6));
    FX.dust(g, t, { count: 30, color: M.key }); overlays(g, t, info, p);
  },
  hands(g, t, info, p) { // Mia's small hand squeezing Leo's
    bgBlur(g, t, p, 14, 1.6); const M = mood(p.mood || 'dusk'), sq = ease.out(prog(t, 0.4, 0.9)), cx = E.W / 2, cy = E.H * 0.6;
    seg(g, [[cx - 700, cy + 120], [cx - 60, cy]], 150, ink()); circle(g, cx - 20, cy, 120, ink()); for (let i = 0; i < 4; i++) seg(g, [[cx + 40, cy - 60 + i * 38], [cx + 150 - sq * 30, cy - 50 + i * 36]], 34, ink());
    seg(g, [[cx + 700, cy + 200], [cx + 100 - sq * 20, cy + 70]], 82, CAST.mia.color); seg(g, [[cx + 260, cy + 120], [cx + 40 - sq * 20, cy + 56]], 62, ink()); circle(g, cx + 40 - sq * 20, cy + 56, 44, ink());
    seg(g, [[cx - 700, cy + 56], [cx - 60, cy - 90]], 5, alpha(M.rim, 0.6)); FX.rings(g, cx + 40, cy + 56, t - 0.4, { count: 3, r0: 70, r1: 300, a: 0.4 * sq }); FX.dust(g, t, { count: 24, color: M.key }); overlays(g, t, info, p);
  },
  phone(g, t, info, p) { // glowing phone, message types out
    bgBlur(g, t, { ...p, set: 'bedroom', rock: 0.04 }, 14, 1.6); const M = mood('night'), cx = E.W / 2, cy = E.H * 0.52, w = V(400, 520), h = V(740, 940);
    const buzz = t < 1.2 && !p.quiet ? Math.sin(t * 60) * 5 : 0; g.save(); g.translate(cx + buzz, cy); rr(g, -w / 2 - 14, -h / 2 - 14, w + 28, h + 28, 54); g.fillStyle = '#0c0c12'; g.fill(); rr(g, -w / 2, -h / 2, w, h, 42); g.fillStyle = linGrad(g, 0, -h / 2, 0, h / 2, ['#17263c', '#0c1522']); g.fill(); glow(g, 0, 0, w * 1.6, '#7fd0d6', 0.25);
    text(g, 'UNKNOWN NUMBER', 0, -h / 2 + 70, { size: V(30, 34), color: '#9fb6d8', font: FONTS.ui, weight: 900, spacing: 2 }); const msg = p.msg || 'Did you feel that too?', n = Math.floor(clamp((t - (p.msgAt ?? 1.3)) / 1.0) * msg.length);
    rr(g, -w / 2 + 30, -60, w - 60, 130, 30); g.fillStyle = '#2a4a78'; g.fill(); text(g, msg.slice(0, n), 0, 5, { size: V(36, 40), color: '#f4efe6', font: FONTS.ui, weight: 800 }); g.restore();
    if (t < 1.4 && !p.quiet) FX.rings(g, cx, cy, t, { count: 3, r0: 300, r1: 520, a: 0.3, color: '#9fe8ff' }); overlays(g, t, info, p);
  },
  pizza(g, t, info, p) { bgBlur(g, t, { ...p, set: 'cafeteria' }, 14, 1.5); const x = E.W / 2, y = E.H * 0.58; g.save(); g.translate(x, y); g.rotate(-0.15); poly(g, [[-260, -150], [260, -120], [0, 250]], '#e8b050'); poly(g, [[-260, -150], [260, -120], [250, -80], [-250, -110]], '#b0763a'); for (const [dx, dy] of [[-100, -50], [60, -20], [-10, 80], [120, -60]]) { circle(g, dx, dy, 34, '#c63a2a'); circle(g, dx - 8, dy - 8, 10, '#e05a48'); } g.restore(); FX.dust(g, t, { count: 30, color: '#ffe0b0' }); for (let i = 0; i < 3; i++) { g.strokeStyle = alpha('#ffffff', 0.22); g.lineWidth = 7; g.lineCap = 'round'; g.beginPath(); for (let k = 0; k <= 18; k++) { const yy = y - 220 - k * 14, xx = x - 70 + i * 70 + Math.sin(t * 2 + k * 0.5 + i) * 16; k ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.stroke(); } overlays(g, t, info, p); },
};
function floorLine(g, GY, M) { g.fillStyle = shade(M.floor, -0.1); g.fillRect(-E.W, GY, E.W * 3, E.H); }
// --- blueprint diagrams ---
const C = () => ({ ui: S().ui, bp: UI.bpStroke() });
const draw = (g, t, a, b, fn) => { const k = ease.out(prog(t, a, b)); if (k > 0) fn(k); };
function ringLoop(g, cx, cy, rx, ry, rot, col, w, k, t, dots = 0) {
  g.save(); g.translate(cx, cy); g.rotate(rot); g.strokeStyle = col; g.lineWidth = w; g.lineCap = 'round'; g.beginPath(); g.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2 * k); g.stroke();
  for (let i = 0; i < dots; i++) { const a = (t * 0.9 + i / dots) * Math.PI * 2; if (a % (Math.PI * 2) < Math.PI * 2 * k) circle(g, Math.cos(a) * rx, Math.sin(a) * ry, 7, alpha(S().ui.gold, 0.9)); } g.restore();
}
function eyeIcon(g, x, y, s, col) { g.strokeStyle = col; g.lineWidth = 5 * s; g.beginPath(); g.ellipse(x, y, 54 * s, 30 * s, 0, 0, 7); g.stroke(); circle(g, x, y, 14 * s, col); }
function footIcon(g, x, y, s, col) { g.strokeStyle = col; g.lineWidth = 5 * s; g.beginPath(); g.moveTo(x - 30 * s, y - 40 * s); g.quadraticCurveTo(x - 40 * s, y + 20 * s, x - 10 * s, y + 46 * s); g.quadraticCurveTo(x + 40 * s, y + 56 * s, x + 44 * s, y + 20 * s); g.quadraticCurveTo(x + 40 * s, y - 20 * s, x + 4 * s, y - 40 * s); g.closePath(); g.stroke(); for (let i = 0; i < 3; i++) circle(g, x - 24 * s + i * 22 * s, y + 78 * s, 6 * s, col); }
function brainIcon(g, x, y, s, col, k = 1) { g.strokeStyle = col; g.lineWidth = 6 * s; g.beginPath(); g.arc(x - 28 * s, y, 56 * s, Math.PI * 0.5, Math.PI * 1.5 + 0.2); g.arc(x + 28 * s, y, 56 * s, Math.PI * 1.5 - 0.2, Math.PI * 2.5); g.closePath(); g.stroke(); seg(g, [[x, y - 54 * s], [x, y + 54 * s]], 4 * s, alpha(col, 0.6)); glow(g, x, y, 130 * s, col, 0.12 * k); }
function earIcon(g, x, y, s, col, t) { ringLoop(g, x, y, 56 * s, 30 * s, 0.1, col, 5 * s, 1, t, 0); ringLoop(g, x, y, 56 * s, 30 * s, 1.1, col, 5 * s, 1, t, 0); ringLoop(g, x, y, 56 * s, 30 * s, -1.1, col, 5 * s, 1, t, 0); }
const DIAG = {
  ear(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const cx = E.W / 2, cy = E.H * 0.52, s = V(1, 1.1);
    draw(g, t, 0.2, 1.6, (k) => { ringLoop(g, cx, cy, 250 * s, 120 * s, 0.0, bp, 7, k, t, 3); }); draw(g, t, 0.6, 2.0, (k) => { ringLoop(g, cx, cy, 250 * s, 120 * s, 1.05, bp, 7, k, t + 0.3, 3); }); draw(g, t, 1.0, 2.4, (k) => { ringLoop(g, cx, cy, 250 * s, 120 * s, -1.05, bp, 7, k, t + 0.6, 3); });
    draw(g, t, 2.0, 2.8, (k) => { g.strokeStyle = alpha(ui.gold, k); g.lineWidth = 6; g.beginPath(); for (let i = 0; i < 90; i++) { const a = i * 0.12, r = 8 + i * 0.9; const px = cx + Math.cos(a) * r, py = cy + Math.sin(a) * r; i ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke(); });
    UI.callout(g, t, { at: [cx + 250 * s, cy - 10], to: [cx + 420 * s, cy - 230], str: 'FLUID LOOPS', start: 1.0 }); text(g, 'INNER EAR', cx, E.H * 0.12, { size: V(60, 56), color: ui.cream, font: FONTS.ui, weight: 900, spacing: 6, alpha: ease.out(prog(t, 0.1, 0.6)) }); overlays(g, t, info, p); },
  hairs(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const n = 11, y0 = E.H * 0.72; const flow = Math.sin(t * 1.6) * 0.5;
    for (let k = 0; k < 3; k++) { g.strokeStyle = alpha(bp, 0.25 - k * 0.05); g.lineWidth = 3; g.beginPath(); for (let i = 0; i <= 60; i++) { const x = (i / 60) * E.W, y = y0 - 60 - k * 90 + Math.sin(i * 0.3 + t * 2 + k) * 10; i ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); }
    for (let i = 0; i < n; i++) { const x = E.W * 0.12 + i * (E.W * 0.76) / (n - 1), lean = flow * 120, tipX = x + lean, tipY = y0 - 330; g.strokeStyle = ui.gold; g.lineWidth = 8; g.lineCap = 'round'; g.beginPath(); g.moveTo(x, y0); g.quadraticCurveTo(x + lean * 0.1, y0 - 170, tipX, tipY); g.stroke(); circle(g, tipX, tipY, 12, ui.gold); circle(g, x, y0 + 8, 22, alpha(bp, 0.9)); }
    seg(g, [[0, y0 + 30], [E.W, y0 + 30]], 6, bp); UI.callout(g, t, { at: [E.W * 0.5 + flow * 120, y0 - 330], to: [E.W * 0.74, E.H * 0.2], str: 'HAIR CELLS BEND', start: 0.6 }); overlays(g, t, info, p); },
  sources(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const cy = E.H * 0.5, bx = E.W * 0.78, xs = [E.W * 0.2, E.W * 0.2, E.W * 0.2], ys = [E.H * 0.22, E.H * 0.5, E.H * 0.8]; const at = p.at || [0.4, 1.6, 2.8];
    [['EYES', eyeIcon], ['EARS', earIcon], ['FEET', footIcon]].forEach(([lab, f], i) => (!p.only || p.only.includes(lab.toLowerCase())) && draw(g, t, at[i], at[i] + 0.5, (k) => { g.save(); g.globalAlpha *= k; f(g, xs[i], ys[i], V(1.1, 1.1), i === 1 ? ui.gold : bp, t); text(g, lab, xs[i] + 150, ys[i], { size: V(40, 40), color: i === 1 ? ui.gold : ui.cream, font: FONTS.ui, weight: 900, align: 'left', spacing: 4 }); seg(g, [[xs[i] + 330, ys[i]], [lerp(xs[i] + 330, bx - 150, k), lerp(ys[i], cy, 0.6 * k)]], 4, alpha(bp, 0.8)); g.restore(); }));
    const bt = p.brainAt ?? at[2] + 0.5; draw(g, t, bt, bt + 0.7, (k) => { brainIcon(g, bx, cy, 1.5, ui.cream, k); text(g, 'BALANCE', bx, cy + 150, { size: V(44, 44), color: ui.gold, font: FONTS.ui, weight: 900, spacing: 5 }); }); overlays(g, t, info, p); },
  mismatch(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const L = E.W * 0.22, R = E.W * 0.5, B = E.W * 0.8, y = E.H * 0.42; const bad = ease.out(prog(t, p.badAt ?? 1.5, (p.badAt ?? 1.5) + 0.8));
    eyeIcon(g, L, y - 90, 1.2, bp); text(g, p.agree ? 'EYES: STILL' : 'EYES: STILL', L, y + 20, { size: 38, color: ui.cream, font: FONTS.ui, weight: 900 }); seg(g, [[L - 150, y + 110], [L + 150, y + 110]], 6, bp);
    earIcon(g, R, y - 90, 1.2, ui.gold, t); text(g, p.agree ? 'EARS: STILL' : 'EARS: MOVING', R, y + 20, { size: 38, color: ui.gold, font: FONTS.ui, weight: 900 }); g.strokeStyle = ui.gold; g.lineWidth = 6; g.beginPath(); for (let i = 0; i <= 50; i++) { const px = R - 150 + i * 6, py = y + 110 + (p.agree ? 0 : Math.sin(i * 0.5 + t * 6) * 26); i ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke();
    seg(g, [[L + 190, y - 40], [B - 130, E.H * 0.34]], 4, alpha(bp, 0.7)); seg(g, [[R + 190, y - 40], [B - 130, E.H * 0.34]], 4, alpha(ui.gold, 0.7)); brainIcon(g, B, E.H * 0.34, 1.2, bad > 0.3 ? ui.accent : ui.cream, bad);
    if (p.agree) text(g, 'THEY AGREE', E.W / 2, E.H * 0.8, { size: V(84, 70), color: ui.gold, glow: 22, glowColor: alpha(ui.gold, 0.6), alpha: ease.out(prog(t, 0.8, 1.4)), spacing: 6 }); else text(g, 'MISMATCH', E.W / 2, E.H * 0.8, { size: V(84, 70), color: ui.accent, glow: 26, glowColor: alpha(ui.accent, 0.7), alpha: bad, spacing: 6 }); if (!p.agree && p.sub !== '') text(g, p.sub || 'SEASICKNESS', E.W / 2, E.H * 0.9, { size: V(40, 38), color: ui.cream, font: FONTS.ui, weight: 900, spacing: 4, alpha: bad }); overlays(g, t, info, p); },
  warning(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const x0 = E.W * 0.12, x1 = E.W * 0.88, y = E.H * 0.52; seg(g, [[x0, y], [x1, y]], 6, bp); const k = ease.inOut(prog(t, 0.3, 2.6)); const xm = lerp(x0, x1, 0.74);
    circle(g, x0, y, 18, ui.gold); text(g, 'EARS FEEL IT', x0, y - 70, { size: V(40, 36), color: ui.gold, font: FONTS.ui, weight: 900, spacing: 3 }); const xk = lerp(x0, xm, k); seg(g, [[x0, y], [xk, y]], 12, ui.gold); glow(g, xk, y, 60, ui.gold, 0.6);
    draw(g, t, 2.5, 3.1, (a) => { circle(g, xm, y, 18, ui.accent); text(g, 'MUSCLES MOVE', xm, y - 70, { size: V(40, 36), color: ui.accent, font: FONTS.ui, weight: 900, spacing: 3 }); }); UI.dimension(g, t, { x1: x0, y1: y + 90, x2: xm, y2: y + 90, str: '3 SECONDS', start: 1.0 }); overlays(g, t, info, p); },
  bars(g, t, info, p) { UI.blueprint(g); const { ui } = C(); text(g, p.title || '', E.W / 2, E.H * 0.18, { size: V(56, 52), color: ui.cream, font: FONTS.ui, weight: 900, spacing: 5 }); UI.compareBars(g, t, { rows: p.rows, x: V(260, 120), y: E.H * V(0.42, 0.38), w: V(1300, 840), start: 0.3 }); overlays(g, t, info, p); },
  curve(g, t, info, p) { UI.blueprint(g); UI.dataCard(g, t, { title: p.title || 'SEASICK ON DRY LAND', subtitle: p.subtitle || 'NAUSEA', from: p.v0 ?? 10, to: p.v1 ?? 1, decimals: 0, unit: '/10', start: 0.4, dur: 2.2, shape: 0.6, labels: p.labels || [[0, 'DAY 1'], [0.55, 'WEEK 3'], [1, 'SEA LEGS']], total: info.dur }); },
  beam(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const cx = E.W / 2, y = E.H * 0.6, w = V(400, 360); rr(g, cx - w / 2, y, w, 70, 10); g.strokeStyle = bp; g.lineWidth = 6; g.stroke(); g.fillStyle = alpha(bp, 0.12); g.fill(); UI.lineFigure(g, { x: cx, y, s: V(2.1, 1.9), pose: POSES.stand, color: alpha(ui.cream, 0.9) }); UI.dimension(g, t, { x1: cx - w / 2, y1: y + 130, x2: cx + w / 2, y2: y + 130, str: '10 CM WIDE', start: 0.5 }); overlays(g, t, info, p); },
  towers(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const gy = E.H * 0.86, th = E.H * 0.7; for (const x of [E.W * 0.32, E.W * 0.62]) { g.strokeStyle = bp; g.lineWidth = 5; g.strokeRect(x - 60, gy - th, 120, th); for (let k = 1; k < 18; k++) seg(g, [[x - 60, gy - k * th / 18], [x + 60, gy - k * th / 18]], 1.5, alpha(bp, 0.35)); }
    const k = ease.inOut(prog(t, 0.4, 2)); seg(g, [[E.W * 0.32 + 60, gy - th], [lerp(E.W * 0.32 + 60, E.W * 0.62 - 60, k), gy - th]], 6, ui.gold); const wx = lerp(E.W * 0.32 + 60, E.W * 0.62 - 60, k); UI.lineFigure(g, { x: wx, y: gy - th, s: 0.55, pose: POSES.stand, color: ui.cream }); UI.dimension(g, t, { x1: E.W * 0.82, y1: gy, x2: E.W * 0.82, y2: gy - th, str: '400 M UP', start: 1.4 }); text(g, '1974', E.W * 0.47, gy - th - 90, { size: V(64, 56), color: ui.gold, glow: 20, glowColor: alpha(ui.gold, 0.5), alpha: ease.out(prog(t, 0.3, 0.8)) }); overlays(g, t, info, p); },
  swaybridge(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const x0 = E.W * 0.08, x1 = E.W * 0.92, y = E.H * 0.5, amp = 120 * ease.inOut(prog(t, 0.4, p.dur || 4)), N = 22;
    g.strokeStyle = bp; g.lineWidth = 9; g.beginPath(); for (let i = 0; i <= 80; i++) { const u = i / 80, px = lerp(x0, x1, u), py = y + Math.sin(u * 6.28 * 1 - t * 4) * amp * Math.sin(u * 3.14); i ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke();
    for (let i = 0; i < N; i++) { const u = (i + 0.5) / N, px = lerp(x0, x1, u), sync = ease.inOut(prog(t, 0.4, p.dur || 4)), ph = (1 - sync) * (i * 2.4) , py = y + Math.sin(u * 6.28 - t * 4) * amp * Math.sin(u * 3.14) + Math.sin(t * 6 + ph) * 26 - 36; circle(g, px, py, 11, ui.cream); }
    text(g, p.label || 'STEPS SYNC → SWAY GROWS', E.W / 2, E.H * 0.2, { size: V(56, 48), color: ui.gold, font: FONTS.ui, weight: 900, spacing: 4, glow: 16, glowColor: alpha(ui.gold, 0.5) }); overlays(g, t, info, p); },
  space(g, t, info, p) { UI.blueprint(g); const { ui, bp } = C(); const k = ease.out(prog(t, 0.3, 1)); text(g, 'EARTH', E.W * 0.28, E.H * 0.2, { size: 44, color: ui.cream, font: FONTS.ui, weight: 900, spacing: 5 }); text(g, 'ORBIT', E.W * 0.72, E.H * 0.2, { size: 44, color: ui.gold, font: FONTS.ui, weight: 900, spacing: 5 });
    earIcon(g, E.W * 0.28, E.H * 0.5, 1.5, bp, t); seg(g, [[E.W * 0.28, E.H * 0.64], [E.W * 0.28, E.H * 0.86]], 8, ui.cream); poly(g, [[E.W * 0.28 - 24, E.H * 0.84], [E.W * 0.28 + 24, E.H * 0.84], [E.W * 0.28, E.H * 0.9]], ui.cream); text(g, 'GRAVITY', E.W * 0.28, E.H * 0.95, { size: 30, color: ui.cream, font: FONTS.ui, weight: 900 });
    g.save(); g.translate(E.W * 0.72 + Math.sin(t) * 20, E.H * 0.5 + Math.cos(t * 0.8) * 14); g.rotate(t * 0.3); earIcon(g, 0, 0, 1.5, ui.gold, t); g.restore(); text(g, 'SIGNALS CLASH', E.W * 0.72, E.H * 0.8, { size: 40, color: ui.accent, glow: 18, glowColor: alpha(ui.accent, 0.6), font: FONTS.ui, weight: 900, spacing: 3, alpha: k }); overlays(g, t, info, p); },
};
// --- cards ---
const CARD = {
  title(g, t, info, p) { const M = mood('dusk'), cam = { z: 1.06 - 0.06 * ease.inOut(t / info.dur), y: -20 * t };
    layer(g, cam, 0.2, (g) => { backdrop(g, M.sky); FX.sun(g, E.W / 2, E.H * V(0.62, 0.55), V(90, 110), '#fff3dc', M.key, 5); FX.godRays(g, E.W / 2, E.H * V(0.62, 0.55), { count: 14, angle: -Math.PI / 2, spread: Math.PI * 1.6, len: 1800, a: 0.06, t }); });
    layer(g, cam, 0.5, (g) => FX.skyline(g, { x: -200, y: E.H * V(0.74, 0.66), w: E.W + 400, maxH: V(300, 500), color: '#2a1f36', windowColor: alpha(M.practical, 0.8), seed: 21 }));
    layer(g, cam, 0.8, (g) => { g.fillStyle = '#16111e'; g.fillRect(-E.W, E.H * V(0.74, 0.66), E.W * 3, E.H); FX.skyline(g, { x: -200, y: E.H * V(0.8, 0.72), w: E.W + 400, minH: 60, maxH: V(160, 260), color: '#120d18', windowColor: alpha(M.practical, 0.9), lit: 0.25, seed: 5 }); });
    FX.dust(g, t, { count: 30, color: '#ffd9b0', a: 0.4 }); UI.titleCard(g, t, { lines: ['WHAT IF YOUR BALANCE', 'WAS 100X SHARPER?'], dur: info.dur, y: E.H * V(0.4, 0.38) }); },
  bigline(g, t, info, p) { UI.blueprint(g); UI.bigLine(g, t, { str: p.str, dur: info.dur, y: E.H / 2 }); },
  end(g, t, info, p) { UI.endScreen(g, t, { question: p.q || 'What do YOU think?', cast: [CAST.leo, CAST.jake, CAST.mia, CAST.reed, CAST.lee, CAST.teach] }); },
};
export const TPL = { wide, face, insert: (g, t, i, p) => INSERT[p.name](g, t, i, p), diagram: (g, t, i, p) => DIAG[p.name](g, t, i, p), card: (g, t, i, p) => CARD[p.name](g, t, i, p) };
