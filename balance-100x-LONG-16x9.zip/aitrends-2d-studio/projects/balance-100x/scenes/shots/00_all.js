// shots/00_all.js — registers every shot id in story/shots.json; the picture is described by each shot's `params` (see _tpl.js).
import { E, V, registerShot, mood, ease, prog } from '/engine/core.js';
import { POSES } from '/engine/rig2d.js';
import { TPL } from '../_tpl.js';
import { LEO, MIA, JAKE, REED } from '../cast.js';

const D3 = {
  bridge3d: {
    init(T) {
      const M = mood('dusk'), st = T.stage({ mood: 'dusk', fov: V(40, 56), fog: [18, 70], keyPos: [-10, 8, 6], keyIntensity: 2.6, ambient: 1.2 });
      const water = T.ground(120, 120, '#2a2a4a'); water.position.y = -2.2; st.add(water);
      const deck = T.box(30, 0.3, 2.6, '#6a5a64', 0, 0, 0); st.add(deck);
      for (let i = -14; i <= 14; i++) { st.add(T.cyl(0.04, 0.04, 1.1, '#2b2230', i, 0.7, 1.2, 6), T.cyl(0.04, 0.04, 1.1, '#2b2230', i, 0.7, -1.2, 6)); }
      st.add(T.box(30, 0.06, 0.06, '#8a7a8a', 0, 1.25, 1.2), T.box(30, 0.06, 0.06, '#8a7a8a', 0, 1.25, -1.2));
      for (const x of [-15, 15]) st.add(T.box(0.5, 9, 0.5, '#2b2230', x, 4.2, 0));
      for (let i = -3; i <= 3; i++) { const b = T.building(3 + (i & 1), 8 + ((i * 7) % 5), 3, { win: M.practical, seed: 9 + i }); b.position.set(i * 6, 3.5, -22 - (i & 1) * 4); st.add(b); }
      const people = []; for (let i = 0; i < 14; i++) { const f = T.figure3D({ top: 'none', head: 'none' }, { rim: M.rim, pose: POSES.stand, s: 0.9 }); f.position.set(-9 + i * 1.4, 0.15, (i % 3 - 1) * 0.6); f.rotation.y = Math.PI / 2; st.add(f); people.push(f); }
      const leo = T.figure3D(LEO, { rim: M.rim, pose: POSES.stand, s: 1 }); leo.position.set(0, 0.15, 0.3); leo.rotation.y = Math.PI / 2; st.add(leo);
      const mia = T.figure3D(MIA, { rim: M.rim, pose: POSES.stand, s: 0.72 }); mia.position.set(0.6, 0.15, 0.3); mia.rotation.y = Math.PI / 2; st.add(mia);
      return { stage: st, deck, people };
    },
    draw(s, t, info, T) { s.deck.rotation.z = info.still ? 0 : Math.sin(t * 2.2) * 0.02 * (0.3 + 0.7 * ease.inOut(t / info.dur)); T.orbit(s.stage.camera, t, { target: [0, 1, 0], radius: V(11, 14), height: [3.2, 2.2], from: -1.1, to: -0.2, dur: info.dur }); },
  },
  field3d: {
    init(T) {
      const M = mood('golden'), st = T.stage({ mood: 'golden', fov: V(38, 52), fog: [16, 60], keyPos: [-9, 6, 4], keyIntensity: 2.9, ambient: 1.2 });
      st.add(T.ground(120, 120, '#3b4a2a'));
      for (const x of [-4, 4]) st.add(T.cyl(0.06, 0.08, 0.5, '#2b2230', x, 0.25, 0, 8));
      st.add(T.box(8, 0.02, 0.02, '#d0d4dc', 0, 0.12, 0));
      for (const [x, z] of [[-10, -8], [8, -10], [14, -4], [-14, -3]]) st.add(T.tree3D(x, z, 1.3));
      const leo = T.figure3D(LEO, { rim: M.rim, pose: { ...POSES.stand, eF: [30, -150], hF: [60, -150], eB: [-30, -150], hB: [-60, -150] }, s: 1 }); leo.position.set(0, 0.12, 0); st.add(leo);
      return { stage: st, leo };
    },
    draw(s, t, info, T) { s.leo.position.x = -1.5 + 3 * Math.min(1, t / info.dur); T.orbit(s.stage.camera, t, { target: [0, 0.8, 0], radius: V(6, 8), height: [1.6, 1.2], from: -0.9, to: 0.3, dur: info.dur }); },
  },
};
for (const s of E.shots) {
  const p = s.params || {};
  if (D3[p.tpl]) registerShot(s.id, { kind: '3d', ...D3[p.tpl] });
  else if (TPL[p.tpl]) registerShot(s.id, { draw(g, t, info) { TPL[p.tpl](g, t, info, p); } });
}
