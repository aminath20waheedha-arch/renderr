# What If Your Balance Was 100x Sharper? — story bible

**Logline:** You (Leo) wake up with an inner ear a hundred times sharper. Your sensors are perfect, your muscles are normal, so you feel every wobble long before you can fix it. Tone: wonder → motion-sick comedy → suspense → warm resolution → science explainer → sting.

## Cast (one signature colour each, never changes)
| id | role | outfit |
|---|---|---|
| leo | "you", hero | red-orange hoodie `#d64a33` |
| jake | best friend, skater | blue tee, yellow cap |
| mia | little sister (7) | pink dress + pink beanie, kid |
| reed | gymnastics coach | purple tracksuit, yellow headband |
| lee | Dr. Lee | white lab coat, round glasses |
| teach | teacher | green dress, bun |
| plain | crowds, passengers | plain ink |

## Locations (sets in `scenes/_sets.js`)
bus (dusk window strip, scrolling skyline) · street (dusk / golden, curb, lamps) · skate park (golden hour) · classroom (warm window, chalkboard) · gym (beam, cool floodlights) · field (golden, sun and long wire) · ice rink (cold lights, light ice) · elevator · cafeteria · clinic (Dr. Lee, ear poster, monitor) · bedroom (night, moon) · footbridge over the river (dusk, sways) · blueprint void for diagrams.

## Motifs
- Camera roll / deck sway = the world moving while Leo stays level.
- Countdown "3, 2, 1... FLY" with big gold numerals, paid off by "3, 2, 1... FREEZE" on the bridge (time-stop look: hanging droplets, cool tint, flash).
- Blueprint diagrams: inner ear loops, hair cells, eyes + ears + feet → brain, mismatch, 3-second warning, sway chart, sea-legs curve.
- Green tint = motion sickness.

## Acts and music (in `story/shots.json`)
0:00 cold open (mystery) · 0:59 plus montage (playful) · 2:09 the minus + science of seasickness (tension) · 3:13 Mia and the bike (hopeful) · 3:48 bridge crisis (tension, rising) · 5:03 freeze and cheers (triumph) · 5:31 resolution (hopeful) · 5:58 "Is any of this real?" (calm) · 6:34 sting and end screen (dark).

## Notes
Narration is untouched. Word timings were aligned to the audio by pause detection (no Whisper); every shot cuts about 0.12 s before its phrase. To use exact Whisper timings instead, run `python tools/transcribe.py --project projects/balance-100x --script projects/balance-100x/input/script.txt --lang en --model small` and rebuild with `story/build_shots.py`.
