"""Builds story/shots.json from the sentence-anchored shot plan below (narration untouched; cuts land 0.12 s before each phrase)."""
import json, copy
S = json.load(open('sents.json'))
Wd = json.load(open('../timeline/words.json')); Wd = Wd['words'] if isinstance(Wd, dict) else Wd
DUR = round(Wd[-1]['end'] + 1.4, 3)
STAND = {"head":[3,-208],"sh":[0,-174],"hip":[0,-100],"eF":[9,-137],"hF":[13,-101],"eB":[-7,-136],"hB":[-9,-100],"kF":[6,-50],"fF":[3,0],"kB":[-6,-50],"fB":[-11,0]}
ONELEG = {**STAND, "kF":[44,-86], "fF":[16,-58], "eF":[40,-150], "hF":[66,-146], "eB":[-34,-150], "hB":[-62,-146]}
def c(id, x, expr='neutral', pose=None, **k):
    d = dict(id=id, x=x, expr=expr, **k)
    if pose is not None: d['poses'] = [[0, pose]] if not isinstance(pose, list) else pose
    return d
def L(id, x, expr='neutral', pose=None, **k):
    k.setdefault('facing', 1); return c(id, x, expr, pose, **k)   # left, facing right (hero side)
def R(id, x, expr='neutral', pose=None, **k):
    k.setdefault('facing', -1); return c(id, x, expr, pose, **k)  # right, facing left
def W(set, chars, scene, **p): return ('wide', dict(tpl='wide', set=set, chars=chars, **p), scene)
def F(who, expr, scene, set='bus', **p): return ('face', dict(tpl='face', who=who, expr=expr, set=set, **p), scene)
def I(name, scene, **p): return ('insert', dict(tpl='insert', name=name, **p), scene)
def D(name, scene, **p): return ('diagram', dict(tpl='diagram', name=name, **p), scene)
def C(name, scene, **p): return ('card', dict(tpl='card', name=name, **p), scene)
def T3(name, scene, **p): return ('3d', dict(tpl=name, **p), scene)
Z = lambda a, b: dict(z=[a, b])
def cam(z=(1, 1.06), x=(0, 0), y=(0, 0), r=(0, 0)): return dict(z=list(z), x=list(x), y=list(y), r=list(r))
def plain(xs, expr='neutral', pose='relaxed', **k):
    out = []
    for i, x in enumerate(xs):
        kk = dict(k); kk.setdefault('facing', 1 if i % 2 else -1); kk.setdefault('seed', i + 1); out.append(c('plain', x, expr, pose, **kk))
    return out
def lab(str_, **k): return dict(k='label', str=str_, **k)

# (sentence, word-offset, shot, extras)  extras: tr (transition), sfx, amb, bars
PLAN = [
 (0,0, W('bus', plain([0.18,0.82], 'scared', 'reach', rot=[0.05,0.05], wob=6) + [L('leo',0.5,'neutral','relaxed')], 'wide bus, everyone grabs poles and lurches, Leo calm in the middle', cam=cam((1,1.05)), sway=dict(amp=0.035,freq=0.6), fx=['dust']), dict(amb=('hum',-24), sfx=[(0.1,'whoosh',-10)])),
 (2,0, W('bus', [L('leo',0.5,'smirk','relaxed',s=1.7)], 'medium: Leo stands hands free', cam=cam((1.15,1.25)), sway=dict(amp=0.03,freq=0.6)), dict(amb=('hum',-24))),
 (3,0, W('bus', [L('leo',0.5,'neutral','relaxed',s=1.5)] + plain([0.12,0.88],'scared','reach',rot=[0.06,0.06],wob=5), 'Leo just stands there while the bus sways', cam=cam((1,1.08),(0,-30)), sway=dict(amp=0.04,freq=0.55)), dict(amb=('hum',-24))),
 (4,0, W('bus', [L('leo',0.34,'neutral','relaxed'), R('jake',0.66,'shocked','reach',rot=[0.04,0.04],wob=5)], 'two-shot: Jake clings to a pole and stares at Leo', cam=cam((1.05,1.12)), sway=dict(amp=0.03,freq=0.6)), dict(amb=('hum',-24))),
 (5,0, F('jake','shocked','giant face: Jake, wide-eyed', set='bus', talk=True, rimSide=1, sway=dict(amp=0.03,freq=0.6), wob=5), dict(amb=('hum',-24))),
 (7,0, W('bus', [L('leo',0.5,'smirk','shrug',s=1.6)], 'Leo shrugs', cam=cam((1.1,1.2)), sway=dict(amp=0.03,freq=0.6)), dict(amb=('hum',-24))),
 (8,0, W('street', [L('leo',[0.25,0.75],'smile',None,walk=True,s=1.5,dy=-30)], 'Leo walks the curb like a tightrope, tracking shot', cam=cam((1,1.05),(-60,40)), mood='dusk'), dict(tr='whip', amb=('city',-26), sfx=[(0.2,'footstep',-14)])),
 (9,0, W('bus', [L('leo',0.5,'smirk',ONELEG,s=1.6)] + plain([0.15,0.85],'scared','reach',rot=[0.05,0.05],wob=6), 'Leo on one leg in the moving train', cam=cam((1.05,1.1)), sway=dict(amp=0.04,freq=0.6)), dict(amb=('hum',-24))),
 (10,0, I('coffee','insert: coffee cup dead level, world rocks behind', set='bus', rock=0.05, mood='interiorCool'), dict(amb=('hum',-24), sfx=[(0.3,'blip',-12)])),
 (11,0, W('street', [L('leo',0.5,'smile','relaxed',s=1.5)], 'Leo introduced, dusk street', cam=cam((1,1.06)), ui=[lab('LEO', at=0.5, y=0.2*1080)], mood='dusk'), dict(tr='dip', amb=('city',-26))),
 (12,0, W('street', [L('leo',0.5,'nervous','relaxed',s=1.5,rot=[0.04,0.04],wob=4)], 'yesterday: Leo wobbles like anyone', cam=cam((1,1.05)), mood='dusk'), dict(amb=('city',-26))),
 (13,0, F('leo','determined','giant face: Leo, ear ringing', set='street', rings=True, mood='dusk'), dict(tr='flash', sfx=[(0.1,'shimmer',-10)])),
 (14,0, D('ear','blueprint: three fluid loops of the inner ear'), dict(tr='zoom', bars='none', sfx=[(0.3,'blip',-12)])),
 (15,0, D('hairs','blueprint: hair cells bending with the fluid'), dict(bars='none')),
 (16,0, D('sources','blueprint: ear signal reaches the brain', only=['ears'], at=[0.3,0.3,0.3], brainAt=1.2), dict(bars='none')),
 (17,0, W('gym', plain([0.22,0.5,0.78],'worried','ready',rot=[0.06,0.06],wob=5), 'normal people wobble on one leg, eyes closed', cam=cam((1,1.05)), ui=[dict(k='readout',label='NORMAL:',value='UNDER 1 MIN',word='minute')]), dict(amb=('roomtone',-26))),
 (18,0, D('bars','bars: normal vs you', title='ONE LEG, EYES CLOSED', rows=[dict(label='NORMAL: 1 MIN',v=0.04),dict(label='YOU: 1 HOUR',v=1.0)]), dict(bars='none', sfx=[(0.5,'pop',-12)])),
 (20,0, F('leo','smirk','giant face: Leo, 100x badge', set='street', ui=[dict(k='badge',str='100x',at=0.3)], mood='dusk'), dict(tr='flash', sfx=[(0.2,'powerup',-10)])),
 (21,0, C('bigline','card: THE RULE', str='BUT THERE IS A RULE'), dict(tr='dip', bars='none')),
 (22,0, D('bars','bars: sensors 100x', title='SENSORS', rows=[dict(label='NORMAL EARS',v=0.01),dict(label='YOUR EARS',v=1.0)], ui=[dict(k='badge',str='100x',at=0.8)]), dict(bars='none')),
 (23,0, D('bars','bars: muscles unchanged', title='MUSCLES', rows=[dict(label='NORMAL MUSCLES',v=0.45),dict(label='YOUR MUSCLES',v=0.45)], ui=[dict(k='badge',str='1x',at=0.8)]), dict(bars='none')),
 (24,0, W('street', [L('leo',0.5,'nervous','ready',s=1.6)], 'Leo feels every wobble before he can react', cam=cam((1,1.08)), sway=dict(amp=0.025,freq=0.7,ramp=True), mood='dusk'), dict(amb=('city',-26))),
 (25,0, C('title','title card over the dusk skyline'), dict(tr='fade', bars='scope', sfx=[(0.0,'riser',-12),(2.2,'stinger',-8)])),

 (26,0, W('skate', [L('leo',0.35,'smile','relaxed',s=1.1), R('jake',0.7,'happy','relaxed',s=1.1)], 'establishing: the skate park at golden hour', cam=cam((1,1.07),(0,-30)), mood='golden'), dict(tr='whip', amb=('wind',-26), sfx=[(0.0,'whoosh',-9)])),
 (27,0, W('skate', [R('jake',[0.9,0.3],'joy',None,walk=True,run=True,s=1.3,trail=dict(count=4,dx=40))], 'Jake drops in, running streak', cam=cam((1,1.04),(30,0)), mood='golden', fx=['speed']), dict(amb=('wind',-26))),
 (28,0, I('board','insert: skateboard, feet perfectly still', set='skate'), dict(sfx=[(0.1,'footstep',-14)], amb=('wind',-26))),
 (30,0, W('skate', [L('leo',[0.3,0.7],'smirk','relaxed',s=1.3), R('jake',0.85,'shocked','sitBack',s=1.3)], 'Leo glides, zero falls, Jake stunned', cam=cam((1,1.06)), mood='golden', ui=[dict(k='readout',label='FALLS:',value='0',word='zero')]), dict(amb=('wind',-26))),
 (32,0, F('jake','shocked','giant face: Jake, jaw drop', set='skate', mood='golden', talk=True, rimSide=1), dict(amb=('wind',-26))),
 (33,0, W('classroom', [R('teach',0.28,'smile','point',s=1.3,facing=1), L('leo',0.72,'neutral','sit',s=1.3,facing=-1)], 'establishing: classroom, warm window light', cam=cam((1,1.06),(-20,0)), mood='interiorWarm'), dict(tr='whip', amb=('roomtone',-26), sfx=[(0.0,'whoosh',-9)])),
 (34,0, I('desk','insert: desk wobbling on uneven legs', fixAt=99), dict(amb=('roomtone',-26))),
 (35,0, F('leo','worried','giant face: Leo senses the wobble', set='classroom', mood='interiorWarm', sway=dict(amp=0.02,freq=0.8)), dict(amb=('roomtone',-26))),
 (36,0, I('desk','insert: folded paper shim under the short leg', fixAt=0.9), dict(sfx=[(0.8,'pop',-10)], amb=('roomtone',-26))),
 (37,0, W('classroom', [L('leo',0.34,'smile','relaxed',s=1.4), R('teach',0.66,'happy','talk',s=1.4,talk=True)], 'teacher smiles, thanks Leo', cam=cam((1.04,1.1)), mood='interiorWarm'), dict(amb=('roomtone',-26))),
 (39,0, W('gym', [R('reed',0.8,'neutral','crossArms',s=1.2), L('leo',0.3,'neutral','relaxed',s=1.2)], 'establishing: gym and balance beam', cam=cam((1,1.06),(20,0)), mood='interiorCool'), dict(tr='whip', amb=('roomtone',-26), sfx=[(0.0,'whoosh',-9)])),
 (40,0, D('beam','blueprint: beam is 10 cm wide'), dict(bars='none', sfx=[(0.5,'pop',-12)])),
 (41,0, W('gym', [L('leo',[0.25,0.7],'neutral',None,walk=True,s=1.2,dy=-136), R('reed',0.85,'neutral','crossArms',s=1.2)], 'Leo crosses the beam, Reed watching', cam=cam((1,1.05)), mood='interiorCool'), dict(amb=('roomtone',-26))),
 (42,0, I('feet','insert: feet walking backwards on the beam', set='gym', surface='beam', walk=True, wobble=0.2, mood='interiorCool'), dict(sfx=[(0.3,'footstep',-14)], amb=('roomtone',-26))),
 (43,0, I('clip','insert: coach drops his clipboard', set='gym'), dict(sfx=[(0.7,'hit',-8)], amb=('roomtone',-26))),
 (44,0, F('reed','surprised','giant face: Coach Reed, stunned', set='gym', mood='interiorCool', talk=True, rimSide=1), dict(amb=('roomtone',-26))),
 (45,0, W('field', [L('leo',0.3,'smile','relaxed',s=1.0)], 'establishing: open field, long wire', cam=cam((1,1.07)), mood='golden', fx=['dust','lens']), dict(tr='whip', amb=('wind',-26), sfx=[(0.0,'whoosh',-9)])),
 (46,0, D('towers','blueprint: 1974 Twin Towers wire walk', ), dict(tr='zoom', bars='none', sfx=[(0.4,'blip',-12)])),
 (46,9, W('street', plain([0.2,0.4,0.6,0.8],'awe','pointUp',facing=1), 'crowd gazes up, four hundred meters up', cam=cam((1,1.06),(0,-60)), mood='dusk'), dict(amb=('city',-26))),
 (47,0, F('jake','confused','giant face: Jake, doubtful', set='street', mood='dusk', rimSide=1), dict(amb=('city',-26))),
 (48,0, T3('field3d','3D orbit: Leo on a wire in a field'), dict(bars='scope', amb=('wind',-26))),
 (49,0, I('feet','insert: feet on a 5 cm wire', set='field', surface='wire', mood='golden', wobble=0.3, ui=[lab('5 CM', at=0.4, y=0.2*1080)]), dict(amb=('wind',-26))),
 (50,0, F('leo','sleepy','giant face: Leo, eyes closed', set='field', mood='golden'), dict(amb=('wind',-26))),
 (51,0, W('field', [L('leo',0.45,'smirk','relaxed',s=1.3), R('jake',0.7,'joy','cheer',s=1.3)], 'Jake cheers, Leo grins', cam=cam((1,1.05)), mood='golden'), dict(amb=('wind',-26), sfx=[(0.2,'cheer',-14)])),
 (53,0, W('rink', [L('leo',0.3,'smile','relaxed',s=1.1)], 'establishing: the ice rink, cold lights', cam=cam((1,1.07),(0,-20)), mood='interiorCool', fx=['dust']), dict(tr='whip', amb=('murmur',-26), sfx=[(0.0,'whoosh',-9)])),
 (54,0, W('rink', [L('leo',0.4,'smile','relaxed',s=1.4), R('mia',0.62,'happy','jump',s=1.4)], 'Mia begs to come, bouncing', cam=cam((1.02,1.08)), mood='interiorCool'), dict(amb=('murmur',-26))),
 (55,0, W('rink', plain([0.1,0.28,0.5,0.7,0.9],'scared','reach',rot=[0.07,0.07],wob=5), 'beginners cling to the wall', cam=cam((1,1.05)), mood='interiorCool'), dict(amb=('murmur',-26))),
 (56,0, W('rink', [L('leo',[0.2,0.8],'smirk','relaxed',s=1.4,trail=dict(count=4,dx=-40),facing=-1)], 'Leo skates backwards, afterimages', cam=cam((1,1.05),(30,0)), mood='interiorCool', fx=['speed']), dict(amb=('murmur',-26), sfx=[(0.2,'swish',-10)])),
 (58,0, F('mia','awe','giant face: Mia gasps', set='rink', mood='interiorCool', rimSide=1), dict(amb=('murmur',-26))),
 (59,0, F('mia','surprised','giant face: Mia, "are you magic?"', set='rink', mood='interiorCool', talk=True, rimSide=1), dict(amb=('murmur',-26))),
 (61,0, F('leo','smirk','giant face: Leo, "just sharper"', set='rink', mood='interiorCool', talk=True), dict(amb=('murmur',-26))),
 (63,0, C('bigline','card: the minus', str='BUT... THE MINUS'), dict(tr='dip', bars='none', sfx=[(0.1,'impact',-8)])),

 (64,0, W('street', [L('leo',0.5,'nervous','ready',s=1.6)], 'the price: the street sways around Leo', cam=cam((1,1.06)), sway=dict(amp=0.05,freq=0.7), mood='dusk', shake=4), dict(amb=('city',-26))),
 (66,0, W('lift', [L('leo',0.5,'worried','relaxed',s=1.6)], 'Leo in the elevator, lights swimming', cam=cam((1,1.07)), sway=dict(amp=0.03,freq=0.9), mood='interiorCool'), dict(tr='whip', amb=('hum',-24), sfx=[(0.0,'whoosh',-9)])),
 (67,0, F('leo','worried','giant face: Leo feels the lift start', set='lift', rings=True, mood='interiorCool'), dict(amb=('hum',-24))),
 (68,0, F('leo','confused','giant face: eyes say nothing moved', set='lift', mood='interiorCool', look=[0,0.2]), dict(amb=('hum',-24))),
 (69,0, W('bus', [L('leo',0.5,'worried','relaxed',s=1.5)] + plain([0.15,0.85],'neutral','relaxed'), 'the school bus, Leo uneasy', cam=cam((1,1.06)), sway=dict(amp=0.04,freq=0.6), mood='interiorCool'), dict(tr='whip', amb=('hum',-24), sfx=[(0.0,'whoosh',-9)])),
 (70,0, W('bus', [L('leo',0.5,'scared','ready',s=1.6,rot=[0.08,0.08],wob=3)], 'every turn feels like a roller coaster', cam=cam((1.05,1.15)), sway=dict(amp=0.08,freq=0.8), mood='interiorCool', fx=['speed']), dict(amb=('hum',-24))),
 (71,0, W('cafeteria', [L('leo',0.35,'neutral','relaxed',s=1.2)] + plain([0.62,0.8],'happy','sit',s=1.2), 'establishing: the cafeteria', cam=cam((1,1.06)), mood='interiorWarm'), dict(tr='whip', amb=('murmur',-24), sfx=[(0.0,'whoosh',-9)])),
 (72,0, W('cafeteria', [L('leo',0.35,'nervous','ready',s=1.3)] + plain([0.62,0.8],'happy','sit',s=1.3), 'the floor sways, only for Leo', cam=cam((1,1.04)), sway=dict(amp=0.06,freq=0.7), mood='interiorWarm'), dict(amb=('murmur',-24))),
 (74,0, F('leo','worried','giant face: Leo, stomach flips, green tint', set='cafeteria', mood='interiorWarm', wob=7, tint=['#3a8a3a',0.22], sway=dict(amp=0.04,freq=0.8)), dict(amb=('murmur',-24), sfx=[(0.2,'glitch',-14)])),
 (75,0, W('cafeteria', [L('leo',0.34,'nervous','relaxed',s=1.5), R('jake',0.66,'worried','point',s=1.5,talk=True)], 'Jake points: you are green', cam=cam((1.03,1.1)), tint=['#3a8a3a',0.18], mood='interiorWarm'), dict(amb=('murmur',-24))),
 (77,0, I('pizza','insert: a slice of pizza', set='cafeteria'), dict(amb=('murmur',-24), sfx=[(0.3,'blip',-12)])),
 (78,0, F('leo','worried','giant face: Leo, it is not the pizza', set='cafeteria', mood='interiorWarm', tint=['#3a8a3a',0.2], talk=True), dict(amb=('murmur',-24))),
 (79,0, C('bigline','card: why?', str='WHY DOES IT HAPPEN?'), dict(tr='fade', bars='none')),
 (80,0, D('sources','blueprint: brain listens to two sources, eyes and ears', only=['eyes','ears'], at=[2.3,3.2,3.2], brainAt=0.4), dict(bars='none', sfx=[(2.3,'pop',-12),(3.2,'pop',-12)])),
 (83,0, D('mismatch','blueprint: they agree', agree=True), dict(bars='none')),
 (84,0, D('mismatch','blueprint: ears feel motion eyes cannot see', badAt=99, sub=''), dict(bars='none')),
 (85,0, D('mismatch','blueprint: the mismatch causes seasickness', badAt=0.4), dict(bars='none', sfx=[(0.4,'stinger',-10)])),
 (86,0, W('street', [L('leo',0.5,'worried','ready',s=1.6)], 'seasick on dry land', cam=cam((1,1.07)), sway=dict(amp=0.035,freq=0.7), tint=['#3a8a3a',0.18], ui=[lab('SEASICK ON DRY LAND', at=0.5, y=0.16*1080, size=46)], mood='dusk'), dict(tr='dip', amb=('city',-26))),
 (88,0, W('bedroom', [L('leo',0.34,'worried','sit',s=1.3)], 'night: the bed seems to rock', cam=cam((1,1.06)), sway=dict(amp=0.04,freq=0.5), mood='night', fx=['stars','dust']), dict(tr='dip', amb=('roomtone',-26))),
 (89,0, W('street', [L('leo',0.5,'worried','ready',s=1.5)], 'tall buildings sway by design', cam=cam((1.02,1.08),(0,60),r=(-0.01,0.01)), sway=dict(amp=0.015,freq=0.5), ui=[lab('BY DESIGN', at=0.6, y=0.18*1080, size=46)], mood='dusk'), dict(amb=('wind',-26))),
 (90,0, F('leo','worried','giant face: Leo feels that too', set='street', mood='dusk', sway=dict(amp=0.025,freq=0.7)), dict(amb=('city',-26))),
 (91,0, W('clinic', [L('leo',0.3,'worried','relaxed',s=1.3), R('lee',0.7,'thinking','point',s=1.3,prop=dict(type='pointer'))], "Dr. Lee runs every test", cam=cam((1,1.06)), mood='interiorWarm'), dict(tr='whip', amb=('roomtone',-26), sfx=[(0.0,'whoosh',-9)])),
 (92,0, F('lee','thinking','giant face: Dr. Lee, is something broken?', set='clinic', mood='interiorWarm', talk=True, rimSide=1), dict(amb=('roomtone',-26))),
 (94,0, W('clinic', [L('leo',0.3,'worried','relaxed',s=1.4), R('lee',0.7,'smile','shrug',s=1.4)], 'ears are perfect, that is the problem', cam=cam((1.02,1.08)), mood='interiorWarm'), dict(amb=('roomtone',-26))),
 (96,0, F('leo','worried','giant face: a perfect ear is a loud ear', set='clinic', mood='interiorWarm', rings=True, tint=['#10081c',0.3]), dict(amb=('hum',-26), sfx=[(0.2,'heartbeat',-12)])),

 (98,0, W('street', [L('leo',0.35,'smile','relaxed',s=1.4), R('mia',0.62,'happy','cheer',s=1.4)], 'golden hour street: Mia bounces up', cam=cam((1,1.06)), mood='golden'), dict(tr='dip', amb=('city',-26))),
 (99,0, F('mia','smile','giant face: Mia, big smile', set='street', mood='golden', rimSide=1), dict(amb=('city',-26))),
 (100,0, W('street', [L('leo',0.4,'smile','relaxed',s=1.4), R('mia',0.62,'nervous','ready',s=1.4)], 'Mia, seven, learning to ride', cam=cam((1,1.06)), mood='golden'), dict(amb=('city',-26))),
 (101,0, F('mia','confused','giant face: Mia asks why you never fall', set='street', mood='golden', talk=True, rimSide=1), dict(amb=('city',-26))),
 (102,0, F('leo','smile','giant face: Leo, because I am holding on', set='street', mood='golden', talk=True), dict(amb=('city',-26))),
 (103,0, I('hands','insert: Mia squeezes Leo hand', set='street', mood='golden'), dict(sfx=[(0.4,'blip',-12)], amb=('city',-26))),
 (105,0, I('bike','insert: Leo hand on the seat, Mia wobbling', set='street'), dict(amb=('city',-26))),
 (106,0, F('leo','determined','giant face: Leo counts it down', set='street', mood='golden', talk=True), dict(amb=('city',-26))),
 (107,0, W('street', [L('leo',0.36,'determined','ready',s=1.4), R('mia',0.64,'nervous','ready',s=1.4)], 'count: three', cam=cam((1,1.05)), mood='golden', ui=[lab('3', at=0.0, y=0.32*1080, size=260, color='#ffd47e')]), dict(amb=('city',-26), sfx=[(0.0,'blip',-10)])),
 (108,0, W('street', [L('leo',0.36,'determined','ready',s=1.4), R('mia',0.64,'nervous','ready',s=1.4)], 'count: two', cam=cam((1.05,1.1)), mood='golden', ui=[lab('2', at=0.0, y=0.32*1080, size=260, color='#ffd47e')]), dict(amb=('city',-26), sfx=[(0.0,'blip',-10)])),
 (109,0, W('street', [L('leo',0.3,'smile','cheer',s=1.4), R('mia',[0.5,0.95],'joy',None,walk=True,run=True,s=1.4)], 'one... fly: Mia rides away', cam=cam((1,1.08),(0,0)), mood='golden', ui=[lab('FLY', at=0.9, y=0.28*1080, size=180, color='#ffd47e')], fx=['dust','lens']), dict(tr='flash', amb=('city',-26), sfx=[(0.0,'blip',-10),(0.9,'powerup',-10)])),
 (110,0, I('bike','insert: let go, Mia wobbles', set='street', wobble=1.6), dict(amb=('city',-26))),
 (112,0, W('street', [L('leo',0.28,'happy','cheer',s=1.4), R('mia',[0.5,0.95],'joy',None,walk=True,run=True,s=1.4)], 'she does not fall', cam=cam((1,1.05),(40,0)), mood='golden'), dict(amb=('city',-26))),
 (113,0, F('mia','joy','giant face: Mia laughing so loud', set='street', mood='golden', talk=True, rings=True, rimSide=1), dict(amb=('city',-26), sfx=[(0.3,'cheer',-14)])),
 (114,0, W('street', [L('leo',0.36,'happy','relaxed',s=1.4), R('mia',0.64,'joy','jump',s=1.4)], 'again, always again', cam=cam((1,1.06)), mood='golden'), dict(amb=('city',-26))),
 (117,0, W('street', [L('leo',0.36,'determined','ready',s=1.4), R('mia',0.64,'nervous','ready',s=1.4)], 'count: three, again', cam=cam((1.1,1.15)), mood='golden', ui=[lab('3', at=0.0, y=0.32*1080, size=260, color='#ffd47e')]), dict(amb=('city',-26), sfx=[(0.0,'blip',-10)])),
 (118,0, W('street', [L('leo',0.36,'determined','ready',s=1.4), R('mia',0.64,'nervous','ready',s=1.4)], 'count: two, again', cam=cam((1.15,1.2)), mood='golden', ui=[lab('2', at=0.0, y=0.32*1080, size=260, color='#ffd47e')]), dict(amb=('city',-26), sfx=[(0.0,'blip',-10)])),
 (119,0, W('street', [L('leo',0.3,'smile','cheer',s=1.4), R('mia',[0.5,0.95],'joy',None,walk=True,run=True,s=1.4)], 'one... fly, again', cam=cam((1,1.08)), mood='golden', ui=[lab('FLY', at=0.9, y=0.28*1080, size=180, color='#ffd47e')], fx=['dust','lens']), dict(tr='flash', amb=('city',-26), sfx=[(0.9,'powerup',-10)])),

 (120,0, W('street', plain([0.15,0.3,0.7,0.85],'happy','relaxed') + [L('leo',0.42,'smile','relaxed',s=1.3), R('mia',0.58,'happy','relaxed',s=1.3)], 'school trip: kids gather', cam=cam((1,1.05)), mood='golden'), dict(tr='dip', amb=('city',-26))),
 (121,0, T3('bridge3d','3D orbit: footbridge over the river, two hundred people'), dict(tr='fade', bars='scope', amb=('wind',-26))),
 (123,0, W('bridge', [L('leo',[0.3,0.55],'smile',None,walk=True,s=1.3), L('mia',[0.38,0.63],'happy',None,walk=True,s=1.3)] + plain([0.1,0.8],'happy','relaxed',s=1.1), 'Leo and Mia walk mid-bridge', cam=cam((1,1.05),(-30,0)), mood='dusk'), dict(amb=('wind',-26), sfx=[(0.2,'footstep',-14)])),
 (124,0, F('leo','surprised','giant face: Leo feels it', set='bridge', mood='dusk', rings=True), dict(tr='flash', sfx=[(0.1,'shimmer',-10)])),
 (125,0, W('bridge', [L('leo',0.4,'worried','ready',s=1.4), L('mia',0.48,'neutral','relaxed',s=1.4)] + plain([0.15,0.78],'happy','relaxed',s=1.2), 'a tiny sideways sway', cam=cam((1,1.07)), deckSway=dict(amp=14,freq=0.8), mood='dusk'), dict(amb=('wind',-26))),
 (126,0, W('bridge', plain([0.15,0.3,0.7,0.85],'happy','relaxed') + [L('leo',0.45,'worried','ready',s=1.5)], 'nobody else notices', cam=cam((1.04,1.1)), deckSway=dict(amp=18,freq=0.8), mood='dusk'), dict(amb=('wind',-26))),
 (127,0, W('bridge', [L('leo',0.4,'scared','ready',s=1.4), L('mia',0.48,'nervous','relaxed',s=1.4)] + plain([0.15,0.78],'nervous','relaxed',s=1.2), 'a second later the bridge tilts', cam=cam((1,1.06)), sway=dict(amp=0.03,freq=0.6,ramp=True), deckSway=dict(amp=50,freq=0.7), mood='dusk'), dict(amb=('wind',-24), sfx=[(0.2,'riser',-14)])),
 (128,0, W('bridge', plain([0.15,0.3,0.7,0.85],'scared','reach',rot=[0.1,0.1],wob=5) + [L('leo',0.45,'scared','ready',s=1.5)], 'people stumble', cam=cam((1.02,1.08)), sway=dict(amp=0.05,freq=0.7), deckSway=dict(amp=60,freq=0.8), mood='dusk', shake=3), dict(amb=('wind',-24))),
 (129,0, D('swaybridge','top-down: steps start to match', dur=2.0), dict(tr='zoom', bars='none')),
 (130,0, D('swaybridge','top-down: Millennium Bridge, 2000', dur=0.6, label='LONDON MILLENNIUM BRIDGE · 2000'), dict(bars='none', sfx=[(0.3,'pop',-12)])),
 (131,0, C('bigline','card: closed after two days', str='CLOSED AFTER 2 DAYS'), dict(tr='fade', bars='none')),
 (132,0, D('swaybridge','top-down: rhythm makes the sway grow', dur=3.2, label='RHYTHM → SWAY GROWS'), dict(tr='zoom', bars='none')),
 (133,0, C('bigline','card: break the beat', str='BREAK THE BEAT'), dict(bars='none', sfx=[(0.2,'hit',-9)])),
 (134,0, F('leo','scared','giant face: ears scream', set='bridge', mood='dusk', rings=True, wob=9, tint=['#10081c',0.25]), dict(sfx=[(0.1,'impact',-8)])),
 (135,0, W('bridge', [L('leo',0.4,'scared','ready',s=1.5), L('mia',0.5,'nervous','relaxed',s=1.5)] + plain([0.15,0.8],'scared','reach',rot=[0.08,0.08],wob=5), 'you can feel it coming', cam=cam((1,1.1)), sway=dict(amp=0.06,freq=0.7), deckSway=dict(amp=80,freq=0.8), mood='dusk', shake=4), dict(amb=('wind',-24))),
 (136,0, W('bridge', [L('leo',[0.5,0.2],'scared',None,walk=True,run=True,s=1.5,facing=-1)], 'Leo runs for the stairs', cam=cam((1,1.06),(0,0)), sway=dict(amp=0.05,freq=0.8), deckSway=dict(amp=70,freq=0.9), mood='dusk', shake=5, fx=['speed']), dict(amb=('wind',-24))),
 (137,0, F('leo','sad','giant face: Leo, no', set='bridge', mood='dusk', sway=dict(amp=0.03,freq=0.8)), dict(amb=('wind',-24))),
 (138,0, I('feet','insert: feet stuck at normal speed', set='bridge', surface='curb', walk=True, wobble=1.5, mood='dusk'), dict(amb=('wind',-24), sfx=[(0.2,'footstep',-12)])),
 (139,0, D('warning','timeline: ears three seconds of warning'), dict(bars='none', sfx=[(1.0,'tick',-12),(2.0,'tick',-12)])),
 (140,0, W('bridge', [L('leo',0.4,'determined','ready',s=1.5), L('mia',0.5,'nervous','relaxed',s=1.5)], 'muscles need every second', cam=cam((1.05,1.12)), sway=dict(amp=0.04,freq=0.8), deckSway=dict(amp=60,freq=0.8), mood='dusk'), dict(amb=('wind',-24))),
 (141,0, F('leo','determined','giant face: start earlier', set='bridge', mood='dusk', talk=True), dict(amb=('wind',-24))),
 (142,0, W('bridge', [L('leo',0.35,'worried','ready',s=1.3), L('mia',0.43,'nervous','relaxed',s=1.3)] + plain([0.2,0.28,0.55,0.7,0.8],'scared','reach',rot=[0.06,0.06],wob=5,s=1.1), 'the stairs are forty meters away', cam=cam((1,1.04)), deckSway=dict(amp=60,freq=0.8), ui=[dict(k='dim',x1=0.4,y1=0.58,x2=0.93,y2=0.58,str='40 M',at=0.6)], mood='dusk'), dict(amb=('wind',-24))),
 (143,0, I('hands','insert: Mia squeezes your hand', set='bridge', mood='dusk'), dict(sfx=[(0.4,'blip',-12)], amb=('wind',-24))),
 (144,0, F('leo','scared','giant face: only you can feel it', set='bridge', mood='dusk', tint=['#10081c',0.3], rings=True), dict(amb=('wind',-24))),
 (145,0, W('bridge', [L('leo',[0.45,0.15],'worried',None,walk=True,run=True,s=1.5,facing=-1)], 'option one: run alone and be safe', cam=cam((1,1.05)), deckSway=dict(amp=50,freq=0.8), ui=[lab('RUN ALONE', at=0.5, y=0.2*1080, size=60)], mood='dusk', fx=['speed']), dict(amb=('wind',-24))),
 (146,0, W('bridge', [L('leo',0.4,'determined','ready',s=1.5), L('mia',0.5,'nervous','relaxed',s=1.5)] + plain([0.15,0.75,0.88],'scared','reach',rot=[0.06,0.06],wob=5), 'option two: stay and break the rhythm', cam=cam((1,1.07)), deckSway=dict(amp=60,freq=0.8), ui=[lab('STAY', at=0.5, y=0.2*1080, size=60)], mood='dusk'), dict(amb=('wind',-24))),
 (147,0, F('leo','worried','giant face: the stairs or the crowd', set='bridge', mood='dusk', look=[-0.8,0], wob=4), dict(tr='flash', amb=('wind',-24), sfx=[(0.1,'impact',-8)])),
 (148,0, W('bridge', plain([0.12,0.28,0.7,0.86],'scared','reach',rot=[0.1,0.1],wob=6) + [L('leo',0.4,'worried','ready',s=1.5), L('mia',0.49,'nervous','relaxed',s=1.5)], 'you cannot stop every fall', cam=cam((1,1.08)), sway=dict(amp=0.06,freq=0.8), deckSway=dict(amp=80,freq=0.9), mood='dusk', shake=4), dict(amb=('wind',-24))),
 (149,0, F('leo','determined','giant face: but you can feel it coming', set='bridge', mood='dusk', rings=True), dict(amb=('wind',-24), sfx=[(0.2,'shimmer',-10)])),
 (150,0, W('bridge', [L('leo',0.45,'determined','ready',s=1.6), L('mia',0.55,'nervous','relaxed',s=1.6)], 'so you stay', cam=cam((1.05,1.12)), deckSway=dict(amp=70,freq=0.8), mood='dusk'), dict(amb=('wind',-24))),
 (151,0, W('bridge', [L('leo',0.5,'determined','reach',s=1.4,dy=-66)], 'you climb onto a bench', cam=cam((1,1.08),(0,40)), deckSway=dict(amp=70,freq=0.8), extra='bench', mood='dusk', fg=[dict(x=0.05,w=70),dict(x=0.97,w=70)]), dict(amb=('wind',-24))),
 (152,0, F('leo','angry','giant face: Leo shouting', set='bridge', mood='dusk', talk=True, rings=True), dict(amb=('wind',-24), sfx=[(0.1,'impact',-8)])),
 (155,0, W('bridge', plain([0.12,0.25,0.7,0.85],'scared','reach',rot=[0.09,0.09],wob=6) + [L('leo',0.5,'sad','reach',s=1.3,dy=-66)], 'nobody hears you', cam=cam((1,1.06),(0,20)), deckSway=dict(amp=80,freq=0.9), extra='bench', tint=['#10081c',0.2], mood='dusk'), dict(amb=('wind',-24))),
 (156,0, F('mia','determined','giant face: Mia, a tiny voice', set='bridge', mood='dusk', talk=True, rimSide=1), dict(amb=('wind',-24))),
 (157,0, W('bridge', [L('mia',0.5,'determined','pointUp',s=1.9,dy=-66), L('leo',0.35,'worried','ready',s=1.4)], 'Mia on the bench: three', cam=cam((1.1,1.15)), deckSway=dict(amp=80,freq=0.9), extra='bench', ui=[lab('3', at=0.0, y=0.3*1080, size=240, color='#ffd47e')], mood='dusk'), dict(amb=('wind',-24), sfx=[(0.0,'blip',-10)])),
 (158,0, F('mia','determined','giant face: Mia, two', set='bridge', mood='dusk', talk=True, ui=[lab('2', at=0.0, y=0.2*1080, size=240, color='#ffd47e')], rimSide=1), dict(amb=('wind',-24), sfx=[(0.0,'blip',-10)])),
 (159,0, W('bridge', [L('mia',0.5,'joy','cheer',s=1.9,dy=-66), L('leo',0.35,'happy','cheer',s=1.4)] + plain([0.12,0.25,0.7,0.85],'neutral','stand',alpha=1), 'ONE... FREEZE: the crowd stops, droplets hang in the air', cam=cam((1,1.1)), extra='bench', tint=['#7fb0ff',0.18], fx=['drops','lens'], ui=[lab('FREEZE', at=0.5, y=0.2*1080, size=120, color='#bfe3ff')], mood='dusk'), dict(tr='flash', bars='scope', sfx=[(0.0,'freeze',-6),(0.2,'impact',-8)])),
 (160,0, F('mia','joy','giant face: Mia', set='bridge', mood='dusk', rimSide=1, tint=['#7fb0ff',0.1]), dict(amb=('wind',-26))),
 (161,0, W('bridge', plain([0.1,0.22,0.34,0.66,0.78,0.9],'determined','stand') + [L('mia',0.5,'determined','pointUp',s=1.7,dy=-66)], 'the kids copy her', cam=cam((1,1.06)), extra='bench', deckSway=dict(amp=60,freq=0.8,decay=True), mood='dusk'), dict(amb=('wind',-26))),
 (162,0, W('bridge', plain([0.1,0.22,0.34,0.66,0.78,0.9],'determined','stand') + [L('leo',0.45,'happy','relaxed',s=1.5)], 'then the parents', cam=cam((1.02,1.08)), deckSway=dict(amp=40,freq=0.8,decay=True), mood='dusk'), dict(amb=('wind',-26))),
 (163,0, T3('bridge3d','3D: two hundred people stop on the beat', still=True), dict(bars='scope', amb=('wind',-26))),
 (164,0, W('bridge', plain([0.12,0.3,0.7,0.86],'neutral','stand') + [L('leo',0.4,'smile','relaxed',s=1.5), L('mia',0.5,'happy','relaxed',s=1.5)], 'the sway shakes and fades', cam=cam((1.04,1.0)), deckSway=dict(amp=60,freq=0.8,decay=True), sway=dict(amp=0.03,freq=0.7), mood='dusk'), dict(amb=('wind',-26))),
 (165,0, F('leo','smile','giant face: silence, it worked', set='bridge', mood='golden', tint=['#ffd9a0',0.1]), dict(tr='fade', amb=('wind',-28))),
 (167,0, W('bridge', plain([0.1,0.22,0.34,0.66,0.78,0.9],'joy','cheer') + [L('leo',0.45,'happy','cheer',s=1.5), L('mia',0.55,'joy','jump',s=1.5)], 'the whole bridge cheers', cam=cam((1,1.07)), mood='golden', fx=['dust','lens'], crowd=dict(rows=2,size=2.2,cheer=1)), dict(amb=('murmur',-24), sfx=[(0.2,'cheer',-10),(0.4,'applause',-14)])),
 (168,0, W('bedroom', [L('leo',0.36,'surprised','phone',s=1.4,prop='phone')], 'that night: Coach Reed calls', cam=cam((1,1.06)), mood='night', fx=['stars','dust']), dict(tr='dip', amb=('roomtone',-26), sfx=[(0.3,'phonering',-10)])),
 (169,0, F('reed','smile','giant face: Reed, national team', set='gym', mood='interiorCool', talk=True, rimSide=1, ui=[lab('NATIONAL TEAM', at=0.2, y=0.2*1080, size=70)]), dict(amb=('roomtone',-26))),
 (170,0, W('rink', [L('leo',0.5,'happy','cheer',s=1.5)], 'gold medals, crowd roars', cam=cam((1,1.08)), mood='interiorCool', fx=['dust','lens'], crowd=dict(rows=1,size=1.6,cheer=1), ui=[lab('GOLD MEDALS', at=0.2, y=0.2*1080, size=70, color='#ffd47e')]), dict(amb=('murmur',-24), sfx=[(0.1,'cheer',-10)])),
 (171,0, W('rink', [L('leo',0.5,'smile','cheer',s=1.5)], 'fame, flashbulbs', cam=cam((1.05,1.12)), mood='interiorCool', fx=['lens','dust'], ui=[lab('FAME', at=0.2, y=0.2*1080, size=90, color='#ffd47e')]), dict(amb=('murmur',-24), sfx=[(0.1,'flash',-10)])),
 (172,0, F('leo','determined','giant face: you say no', set='bedroom', mood='night'), dict(tr='dip', amb=('roomtone',-26))),
 (173,0, W('gym', [L('leo',[0.5,0.25],'smile',None,walk=True,s=1.3,facing=-1)], 'medals come and go: Leo walks away', cam=cam((1,1.06)), mood='interiorCool'), dict(amb=('roomtone',-26), sfx=[(0.2,'footstep',-14)])),
 (174,0, W('street', [L('leo',0.42,'happy','kneel',s=1.5), R('mia',0.58,'joy','cheer',s=1.5)], 'a sister doesn\'t: Leo and Mia embrace', cam=cam((1.04,1.12)), mood='golden', fx=['dust','lens']), dict(amb=('city',-26), sfx=[(0.2,'shimmer',-12)])),
 (175,0, W('clinic', [L('leo',0.34,'smile','relaxed',s=1.4), R('lee',0.66,'smile','relaxed',s=1.4)], 'weeks later, Dr. Lee smiles', cam=cam((1,1.06)), mood='interiorWarm'), dict(tr='dip', amb=('roomtone',-26))),
 (176,0, D('sources','blueprint: brain learns to trust ears and eyes together', only=['eyes','ears'], at=[0.5,1.8,1.8], brainAt=0.3), dict(bars='none')),
 (177,0, D('curve','curve: sea legs, nausea falls', title='NAUSEA', subtitle='SEA LEGS', v0=10, v1=1, labels=[[0,'DAY 1'],[0.55,'WEEK 3'],[1,'SEA LEGS']]), dict(bars='none', sfx=[(0.4,'counter',-14)])),
 (178,0, W('cafeteria', [L('leo',0.4,'smile','relaxed',s=1.5)] + plain([0.64,0.82],'happy','sit',s=1.3), 'one morning, the floor stops moving', cam=cam((1,1.06)), mood='interiorWarm', fx=['dust','lens']), dict(tr='fade', amb=('murmur',-26))),
 (179,0, I('pizza','insert: eating pizza, finally', set='cafeteria'), dict(amb=('murmur',-26), sfx=[(0.3,'pop',-12)])),
 (180,0, W('cafeteria', [L('leo',0.35,'happy','relaxed',s=1.5), R('jake',0.65,'smirk','relaxed',s=1.5,talk=True)], 'Jake grins: told you', cam=cam((1.03,1.1)), mood='interiorWarm'), dict(amb=('murmur',-26))),
 (182,0, F('leo','smile','giant face: it was not the pizza', set='cafeteria', mood='interiorWarm', talk=True), dict(amb=('murmur',-26))),
 (183,0, W('street', [L('leo',[0.3,0.5],'smile',None,walk=True,s=1.3), L('mia',[0.38,0.58],'happy',None,walk=True,s=1.3), L('jake',[0.22,0.42],'happy',None,walk=True,s=1.3)], 'walking home together at dusk', cam=cam((1,1.04),(0,0)), mood='dusk'), dict(amb=('city',-26))),
 (184,0, W('street', [L('leo',[0.5,0.62],'smile',None,walk=True,s=1.2), L('mia',[0.58,0.7],'happy',None,walk=True,s=1.2)], 'pull-out at sunset: you can feel it coming', cam=cam((1.1,1.0)), mood='dusk', fx=['dust','lens']), dict(amb=('city',-26))),

 (185,0, C('bigline','card: is any of this real?', str='IS ANY OF THIS REAL?'), dict(tr='dip', bars='none', sfx=[(0.1,'stinger',-9)])),
 (186,0, D('sources','blueprint: balance is not one sense', only=['ears'], at=[0.3,0.3,0.3], brainAt=1.6), dict(bars='none')),
 (188,0, D('sources','blueprint: inner ear, eyes, pressure sensors in your feet', at=[0.4,2.2,3.5], brainAt=4.2), dict(bars='none', sfx=[(0.4,'pop',-12),(2.2,'pop',-12),(3.5,'pop',-12)])),
 (189,0, D('bars','bars: cannot sharpen all of it 100x', title='100X SHARPER?', rows=[dict(label='INNER EAR',v=1.0),dict(label='EYES',v=0.12),dict(label='FEET',v=0.12)]), dict(bars='none')),
 (190,0, D('swaybridge','top-down: the sway is real', dur=1.5, label='THE SWAY IS REAL'), dict(bars='none')),
 (191,0, D('mismatch','blueprint: seasickness is real', badAt=0.2), dict(bars='none')),
 (192,0, D('curve','curve: sea legs are real', title='ADAPTATION', subtitle='SEA LEGS', v0=10, v1=1, labels=[[0,'DAY 1'],[0.55,'WEEK 3'],[1,'SEA LEGS']]), dict(bars='none')),
 (193,0, C('bigline','card: astronauts', str='ASTRONAUTS TOO'), dict(bars='none')),
 (194,0, D('space','blueprint: in orbit the signals clash'), dict(bars='none')),
 (195,0, D('curve','curve: most adapt within a few days', title='SPACE SICKNESS', subtitle='ADAPTATION', v0=10, v1=1, labels=[[0,'DAY 1'],[0.55,'DAY 3'],[1,'ADAPTED']]), dict(bars='none')),
 (196,0, C('bigline','card: how far could training push your balance?', str='HOW FAR COULD TRAINING GO?'), dict(bars='none')),

 (197,0, W('bedroom', [L('leo',0.34,'sleepy','sit',s=1.3)], 'that night, your bed rocks', cam=cam((1,1.06)), sway=dict(amp=0.025,freq=0.5), mood='night', fx=['stars','dust']), dict(tr='dip', amb=('roomtone',-26))),
 (198,0, W('bedroom', [L('leo',0.34,'worried','sit',s=1.4)], 'gently, then harder', cam=cam((1.02,1.1)), sway=dict(amp=0.07,freq=0.9,ramp=True), shake=6, mood='night', fx=['stars','dust']), dict(amb=('roomtone',-24), sfx=[(0.1,'riser',-12)])),
 (200,0, I('phone','insert: phone buzzes, unknown number', set='bedroom', msgAt=99), dict(sfx=[(0.0,'phonebuzz',-8)], amb=('roomtone',-26))),
 (202,0, I('phone','insert: the message appears', set='bedroom', msgAt=0.2, quiet=True), dict(sfx=[(0.2,'stinger',-8)], amb=('roomtone',-26))),
 (202,5, F('leo','smile','giant face: Leo, what do you think?', set='bedroom', mood='night', talk=True), dict(tr='fade')),
 (203,0, C('end','end screen: what do you think? subscribe for Part Two', q='What do YOU think?'), dict(tr='fade', bars='none')),
]

shots = []
starts = []
for sidx, woff, shot, ex in PLAN:
    st = S[sidx]; wi = st['i'] + woff
    t0 = Wd[wi]['start'] - 0.12
    starts.append(max(0.0, t0))
starts[0] = 0.0
for i in range(1, len(starts)):
    if starts[i] < starts[i-1] + 0.6: starts[i] = starts[i-1] + 0.6
ends = starts[1:] + [DUR]
wi_list = [S[s]['i'] + w for s, w, _, _ in PLAN]
for k, ((sidx, woff, (kind, params, scene), ex), t0, t1) in enumerate(zip(PLAN, starts, ends)):
    wa = wi_list[k]; wb = wi_list[k+1] if k+1 < len(wi_list) else len(Wd)
    line = ' '.join(w['word'] for w in Wd[wa:wb])
    sh = dict(id=f's{k+1:03d}', start=round(t0, 3), end=round(t1, 3), line=line, scene=scene, set=params.get('set') or params.get('name'), bars=ex.get('bars'), params=params)
    sh['in'] = dict(type=ex.get('tr', 'cut'), dur=0.4 if ex.get('tr') != 'flash' else 0.3)
    sh['sfx'] = [dict(at=a, name=n, gain=g) for a, n, g in ex.get('sfx', [])]
    if ex.get('amb'): sh['amb'] = dict(name=ex['amb'][0], gain=ex['amb'][1])
    if kind == 'diagram' or kind == 'card': sh['captions'] = False
    shots.append(sh)
MUSIC = [(0,58.8,'mystery',0.35),(58.8,128.7,'playful',0.5),(128.7,192.7,'tension',0.5),(192.7,228.2,'hopeful',0.4),(228.2,303.2,'tension',0.8),(303.2,331.2,'triumph',0.6),(331.2,358.3,'hopeful',0.4),(358.3,394.1,'calm',0.3),(394.1,DUR,'dark',0.55)]
out = dict(title='What If Your Balance Was 100x Sharper?', duration=DUR, shots=shots, music=[dict(start=a, end=(b if b != DUR else DUR), mood=m, intensity=i) for a, b, m, i in MUSIC], sfx=[])
json.dump(out, open('shots.json', 'w'), indent=1)
d = [s['end'] - s['start'] for s in shots]; d.sort()
print(len(shots), 'shots; duration', DUR, '; median', round(d[len(d)//2], 2), '; max', round(d[-1], 2), '; min', round(d[0], 2))
